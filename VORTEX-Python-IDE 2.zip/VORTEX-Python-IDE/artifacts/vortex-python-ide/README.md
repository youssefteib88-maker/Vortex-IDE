# VORTEX Python IDE

A responsive, browser-based Python workspace designed for iPhone Safari and desktop browsers.

## Run locally

From the workspace root:

```sh
pnpm install
pnpm --filter @workspace/vortex-python-ide run dev
```

The app uses IndexedDB in the current browser to store projects. Clearing Safari website data also clears those projects, so export a ZIP backup before removing site data or changing browsers.

## Python runtime and security model

VORTEX runs real Python using Pyodide inside a disposable, sandboxed browser frame with an opaque origin. It receives only the active project's files, cannot access the app's same-origin IndexedDB, and is removed when execution is stopped or the user switches projects. It does not run user code inside the web server process and does not expose the host filesystem or shell.

This project does **not** include a FastAPI execution server or authenticated server-side execution API. Docker is not available in the current runtime, so no server-side container sandbox can be launched here. Projects are local to one browser profile and are not shared between people or devices. The browser frame is a local execution boundary, not a replacement for hardened server-side isolation against adversarial code.

The browser runtime is a Python-only environment, not Ubuntu, Debian, Alpine, Bash, or a host shell. Interactive stdin and shell terminal tabs are not currently provided. Python and third-party wheel support depend on the Pyodide version and package compatibility. `micropip` can install supported packages, primarily pure-Python wheels; native extensions, system libraries, and packages requiring a full operating system may fail. The browser does not provide hard CPU, memory, or filesystem quotas. The app enforces a configurable timeout by destroying the sandbox frame, but this is not a hardened server resource boundary. The app must show installation errors rather than reporting a failed installation as successful.

Package installs are project-scoped in VORTEX and restored when the project's browser runtime starts. Installing Python packages executes package build/install code inside the isolated browser frame; use packages you trust.

## Deployment

This is a static React/Vite web artifact. It does not require a persistent process or user database. Deploying the web artifact serves the interface; Python still runs in each visitor's browser. Pyodide is loaded from jsDelivr, so the user's network and any deployment content-security policy must allow that CDN.

## API notes

There is no execution HTTP API in this build. The browser creates a fresh sandboxed frame for each active project and sends it Python source, project files, script arguments, package-manager actions, and non-secret environment variables. Output, errors, duration, and status are returned as frame messages.

## Implemented application scope

The editor is intended to provide IndexedDB-backed projects, nested files, tabs, CodeMirror editing, import/export, browser-side Python execution, and project-scoped compatible package installation. Linux container workflows, remote accounts, shared server workspaces, authenticated server execution, unrestricted `pip`, and interactive shell terminals require a separately provisioned server sandbox and are not claimed here.
