export type RuntimeMessage =
  | { type: "ready"; pythonVersion: string; packages: string[]; failedPackages?: string[] }
  | { type: "output"; stream: "stdout" | "stderr"; text: string }
  | { type: "result"; requestId: string; ok: boolean; durationMs?: number; exitCode?: number; error?: string; value?: string; packages?: string[] }
  | { type: "progress"; requestId: string; text: string }
  | { type: "fatal"; error: string };

export type RuntimeFile = { path: string; content: string };

type RuntimeRequest = {
  type: "run" | "repl" | "install" | "uninstall" | "format" | "inspect";
  requestId: string;
  code?: string;
  fileName?: string;
  args?: string[];
  envVars?: Record<string, string>;
  packageName?: string;
  packages?: string[];
};

type PendingRequest = {
  resolve: (message: RuntimeMessage) => void;
};

const PYODIDE_VERSION = "0.27.7";

function runtimeDocument(channel: string, version: string): string {
  const channelValue = JSON.stringify(channel);
  const versionValue = JSON.stringify(version);
  return `<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"></head><body>
<script type="module">
const CHANNEL = ${channelValue};
const VERSION = ${versionValue};
const send = (message) => parent.postMessage({ ...message, vortexChannel: CHANNEL }, "*");
let pyodide;
let projectPackages = [];
let busy = false;
let operationBusy = false;

async function start(message) {
  try {
    const baseUrl = "https://cdn.jsdelivr.net/pyodide/v" + VERSION + "/full/";
    const module = await import(baseUrl + "pyodide.mjs");
    pyodide = await module.loadPyodide({ indexURL: baseUrl });
    pyodide.setStdout({ batched: (text) => send({ type: "output", stream: "stdout", text: text + "\\n" }) });
    pyodide.setStderr({ batched: (text) => send({ type: "output", stream: "stderr", text: text + "\\n" }) });
    await pyodide.loadPackage("micropip");
    pyodide.FS.mkdirTree("/workspace");
    pyodide.FS.chdir("/workspace");
    for (const file of message.files || []) {
      const path = "/workspace/" + file.path;
      pyodide.FS.mkdirTree(path.slice(0, path.lastIndexOf("/")));
      pyodide.FS.writeFile(path, file.content);
    }
    projectPackages = [];
    const failedPackages = [];
    for (const packageName of message.installedPackages || []) {
      const list = pyodide.toPy([packageName]);
      pyodide.globals.set("__vortex_packages", list);
      try {
        await pyodide.runPythonAsync("import micropip\\nawait micropip.install(__vortex_packages)");
        projectPackages.push(packageName);
      } catch (error) {
        failedPackages.push(packageName);
        send({ type: "output", stream: "stderr", text: "Could not restore " + packageName + ": " + String(error) + "\\n" });
      } finally {
        list.destroy();
        pyodide.globals.delete("__vortex_packages");
      }
    }
    send({
      type: "ready",
      pythonVersion: String(pyodide.runPython("import sys; sys.version.split()[0]")),
      packages: [...projectPackages],
      failedPackages,
    });
  } catch (error) {
    send({ type: "fatal", error: error instanceof Error ? error.message : String(error) });
  }
}

async function run(request) {
  const started = performance.now();
  const args = pyodide.toPy(request.args || []);
  const environment = pyodide.toPy(request.envVars || {});
  pyodide.globals.set("__vortex_args", args);
  pyodide.globals.set("__vortex_env", environment);
  pyodide.globals.set("__vortex_filename", request.fileName || "main.py");
  try {
    await pyodide.runPythonAsync(
      "import os, sys\\n__file__ = __vortex_filename\\nsys.argv = [__file__, *__vortex_args]\\nos.environ.update({str(k): str(v) for k, v in __vortex_env.items()})",
    );
    const result = await pyodide.runPythonAsync(request.code || "");
    const value = result === undefined || result === null ? "" : String(result);
    if (result && typeof result.destroy === "function") result.destroy();
    send({ type: "result", requestId: request.requestId, ok: true, exitCode: 0, durationMs: Math.round(performance.now() - started), value });
  } catch (error) {
    const text = error instanceof Error ? error.message : String(error);
    const exitMatch = text.match(/SystemExit:?\\s*(-?\\d+)?(?:\\r?\\n|$)/);
    if (exitMatch) {
      const exitCode = Number(exitMatch[1] || 0);
      if (exitCode !== 0) send({ type: "output", stream: "stderr", text: text.endsWith("\\n") ? text : text + "\\n" });
      send({
        type: "result",
        requestId: request.requestId,
        ok: exitCode === 0,
        exitCode,
        durationMs: Math.round(performance.now() - started),
        ...(exitCode === 0 ? {} : { error: text }),
      });
      return;
    }
    send({ type: "output", stream: "stderr", text: text.endsWith("\\n") ? text : text + "\\n" });
    send({ type: "result", requestId: request.requestId, ok: false, exitCode: 1, durationMs: Math.round(performance.now() - started), error: text });
  } finally {
    args.destroy();
    environment.destroy();
    pyodide.globals.delete("__vortex_args");
    pyodide.globals.delete("__vortex_env");
    pyodide.globals.delete("__vortex_filename");
  }
}

async function handleRequest(request) {
  if (request.type === "run" || request.type === "repl") return run(request);
  if (request.type === "inspect") {
    send({ type: "result", requestId: request.requestId, ok: true, packages: [...projectPackages] });
    return;
  }
  if (request.type === "install") {
    const packages = request.packages || [];
    send({ type: "progress", requestId: request.requestId, text: "Installing " + packages.join(", ") + "…" });
    const packageList = pyodide.toPy(packages);
    pyodide.globals.set("__vortex_packages", packageList);
    try {
      await pyodide.runPythonAsync("import micropip\\nawait micropip.install(__vortex_packages)");
      projectPackages = [...new Set([...projectPackages, ...packages])];
      send({ type: "result", requestId: request.requestId, ok: true, packages: [...projectPackages] });
    } catch (error) {
      const text = error instanceof Error ? error.message : String(error);
      send({ type: "result", requestId: request.requestId, ok: false, error: text });
    } finally {
      packageList.destroy();
      pyodide.globals.delete("__vortex_packages");
    }
    return;
  }
  if (request.type === "uninstall") {
    const packageName = request.packageName;
    if (!packageName) throw new Error("Choose an installed package to remove.");
    const packageList = pyodide.toPy([packageName]);
    pyodide.globals.set("__vortex_uninstall", packageList);
    try {
      await pyodide.runPythonAsync("import micropip\\nawait micropip.uninstall(__vortex_uninstall)");
      projectPackages = projectPackages.filter((name) => name.toLowerCase() !== packageName.toLowerCase());
      send({ type: "result", requestId: request.requestId, ok: true, packages: [...projectPackages] });
    } catch (error) {
      const text = error instanceof Error ? error.message : String(error);
      send({ type: "result", requestId: request.requestId, ok: false, error: text });
    } finally {
      packageList.destroy();
      pyodide.globals.delete("__vortex_uninstall");
    }
    return;
  }
  if (request.type === "format") {
    pyodide.globals.set("__vortex_source", request.code || "");
    try {
      const formatted = await pyodide.runPythonAsync(
        "import black\\ntry:\\n    black.format_file_contents(__vortex_source, fast=False, mode=black.FileMode())\\nexcept black.NothingChanged:\\n    __vortex_source",
      );
      send({ type: "result", requestId: request.requestId, ok: true, value: String(formatted) });
      if (formatted && typeof formatted.destroy === "function") formatted.destroy();
    } catch (error) {
      const text = error instanceof Error ? error.message : String(error);
      send({ type: "result", requestId: request.requestId, ok: false, error: text });
    } finally {
      pyodide.globals.delete("__vortex_source");
    }
    return;
  }
  send({ type: "result", requestId: request.requestId, ok: false, error: "Unsupported runtime operation." });
}

window.addEventListener("message", async (event) => {
  if (event.source !== parent || event.data?.vortexChannel !== CHANNEL) return;
  const message = event.data;
  if (message.type === "init") {
    if (!pyodide && !busy) {
      busy = true;
      await start(message);
      busy = false;
    }
    return;
  }
  if (!pyodide) return;
  if (operationBusy) {
    send({ type: "result", requestId: message.requestId, ok: false, error: "Python runtime is busy with another operation." });
    return;
  }
  operationBusy = true;
  try {
    await handleRequest(message);
  } catch (error) {
    send({
      type: "result",
      requestId: message.requestId,
      ok: false,
      error: error instanceof Error ? error.message : String(error),
    });
  } finally {
    operationBusy = false;
  }
});
</script></body></html>`;
}

export class PythonRuntime {
  private readonly frame: HTMLIFrameElement;
  private readonly channel = crypto.randomUUID();
  private readonly pending = new Map<string, PendingRequest>();
  private readonly readyPromise: Promise<RuntimeMessage>;
  private resolveReady!: (message: RuntimeMessage) => void;
  private rejectReady!: (error: Error) => void;
  private terminated = false;
  private readonly handleMessage = (event: MessageEvent<RuntimeMessage & { vortexChannel?: string }>) => {
    if (event.source !== this.frame.contentWindow || event.data.vortexChannel !== this.channel) return;
    const message = event.data;
    if (message.type === "ready") this.resolveReady(message);
    if (message.type === "fatal") this.rejectReady(new Error(message.error));
    if (message.type === "result") {
      const pending = this.pending.get(message.requestId);
      pending?.resolve(message);
      this.pending.delete(message.requestId);
    }
    this.onMessage(message);
  };

  constructor(
    _projectId: string,
    files: RuntimeFile[],
    installedPackages: string[],
    private readonly onMessage: (message: RuntimeMessage) => void,
  ) {
    this.readyPromise = new Promise((resolve, reject) => {
      this.resolveReady = resolve;
      this.rejectReady = reject;
    });
    this.frame = document.createElement("iframe");
    this.frame.title = "Isolated Python runtime";
    this.frame.tabIndex = -1;
    this.frame.setAttribute("aria-hidden", "true");
    this.frame.setAttribute("sandbox", "allow-scripts");
    Object.assign(this.frame.style, {
      position: "fixed",
      width: "1px",
      height: "1px",
      left: "-2px",
      bottom: "0",
      opacity: "0",
      border: "0",
      pointerEvents: "none",
    });
    this.frame.srcdoc = runtimeDocument(this.channel, PYODIDE_VERSION);
    window.addEventListener("message", this.handleMessage);
    this.frame.addEventListener(
      "load",
      () => {
        this.frame.contentWindow?.postMessage(
          { vortexChannel: this.channel, type: "init", files, installedPackages },
          "*",
        );
      },
      { once: true },
    );
    document.body.append(this.frame);
  }

  ready(): Promise<RuntimeMessage> {
    return this.readyPromise;
  }

  async request(request: Omit<RuntimeRequest, "requestId">): Promise<RuntimeMessage> {
    if (this.terminated) throw new Error("Python runtime has stopped.");
    await this.readyPromise;
    const requestId = crypto.randomUUID();
    const promise = new Promise<RuntimeMessage>((resolve) => {
      this.pending.set(requestId, { resolve });
    });
    this.frame.contentWindow?.postMessage(
      { ...request, requestId, vortexChannel: this.channel },
      "*",
    );
    return promise;
  }

  stop(): void {
    if (this.terminated) return;
    this.terminated = true;
    window.removeEventListener("message", this.handleMessage);
    this.frame.remove();
    for (const [requestId, pending] of this.pending) {
      pending.resolve({ type: "result", requestId, ok: false, error: "Execution stopped." });
    }
    this.pending.clear();
  }

  dispose(): void {
    this.stop();
  }
}
