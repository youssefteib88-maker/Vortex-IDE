import { getImageMimeType, getFileType, isImagePath } from "@/lib/file-types";

export type PreviewFile = { path: string; content: string; kind?: "file" | "folder" };

const CSP = `<meta http-equiv="Content-Security-Policy" content="default-src 'none'; img-src data: blob:; style-src 'unsafe-inline' data:; script-src 'unsafe-inline'; font-src data:; media-src data: blob:; connect-src 'none'; object-src 'none'; form-action 'none'; base-uri 'none'">`;

function isRemote(reference: string): boolean {
  return /^(?:[a-z][a-z\d+.-]*:|\/\/|#)/i.test(reference.trim());
}

function normalizePath(path: string): string {
  const parts: string[] = [];
  for (const part of path.replace(/\\/g, "/").split("/")) {
    if (!part || part === ".") continue;
    if (part === "..") parts.pop();
    else parts.push(part);
  }
  return parts.join("/");
}

function resolveLocalPath(fromPath: string, reference: string): string | null {
  const raw = reference.trim();
  if (!raw || isRemote(raw)) return null;
  let path = raw.split(/[?#]/, 1)[0];
  try { path = decodeURIComponent(path); } catch { /* Keep the literal path. */ }
  const base = path.startsWith("/") ? "" : fromPath.split("/").slice(0, -1).join("/");
  return normalizePath(base ? `${base}/${path}` : path);
}

function findAttribute(tag: string, name: string): string | null {
  const escapedName = name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const match = tag.match(new RegExp(`\\b${escapedName}\\s*=\\s*(?:"([^"]*)"|'([^']*)'|([^\\s>]+))`, "i"));
  return match ? match[1] ?? match[2] ?? match[3] ?? "" : null;
}

function escapeScriptEnd(content: string): string {
  return content.replace(/<\/script/gi, "<\\/script");
}

function asImageData(file: PreviewFile): string | null {
  if (/^data:image\//i.test(file.content)) return file.content;
  if (getFileType(file.path).icon === "image" && /\.svg$/i.test(file.path) && /^\s*<svg[\s>]/i.test(file.content)) {
    return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(file.content)}`;
  }
  return null;
}

function inlineCss(
  content: string,
  sourcePath: string,
  fileMap: Map<string, PreviewFile>,
  imported = new Set<string>(),
): string {
  let cssText = content.replace(/@import\s+(?:url\()?['"]([^'"]+)['"]\)?\s*;/gi, (original, reference: string) => {
    const importedPath = resolveLocalPath(sourcePath, reference);
    const importedFile = importedPath && fileMap.get(importedPath);
    if (!importedPath || !importedFile || getFileType(importedPath).language !== "css" || imported.has(importedPath)) return original;
    imported.add(importedPath);
    return inlineCss(importedFile.content, importedPath, fileMap, imported);
  });

  cssText = cssText.replace(/url\(\s*(?:(["'])(.*?)\1|([^)]*?))\s*\)/gi, (original, _quote: string, quoted: string, unquoted: string) => {
    const reference = (quoted ?? unquoted ?? "").trim();
    const imagePath = resolveLocalPath(sourcePath, reference);
    const image = imagePath && fileMap.get(imagePath);
    const data = image && isImagePath(imagePath) ? asImageData(image) : null;
    return data ? `url("${data}")` : original;
  });
  return cssText;
}

function hasReferenceTo(html: string, tagName: "script" | "link", attribute: string, targetPath: string, htmlPath: string): boolean {
  const tags = html.match(new RegExp(`<${tagName}\\b[^>]*>`, "gi")) ?? [];
  return tags.some(tag => {
    const reference = findAttribute(tag, attribute);
    return !!reference && resolveLocalPath(htmlPath, reference) === targetPath;
  });
}

function inlineLocalAssets(html: string, htmlPath: string, fileMap: Map<string, PreviewFile>): string {
  let result = html.replace(/<link\b[^>]*>/gi, tag => {
    if (!/\brel\s*=\s*(?:"[^"]*stylesheet[^"]*"|'[^']*stylesheet[^']*'|stylesheet\b)/i.test(tag)) return tag;
    const reference = findAttribute(tag, "href");
    const cssPath = reference && resolveLocalPath(htmlPath, reference);
    const cssFile = cssPath && fileMap.get(cssPath);
    if (!cssFile || getFileType(cssPath).language !== "css") return tag;
    return `<style data-vortex-source="${cssPath.replace(/"/g, "&quot;")}">\n${inlineCss(cssFile.content, cssPath, fileMap)}\n</style>`;
  });

  result = result.replace(/<script\b([^>]*)\bsrc\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))([^>]*)>\s*<\/script\s*>/gi, (tag, before: string, doubleQuote: string, singleQuote: string, bare: string, after: string) => {
    const reference = doubleQuote ?? singleQuote ?? bare ?? "";
    const scriptPath = resolveLocalPath(htmlPath, reference);
    const scriptFile = scriptPath && fileMap.get(scriptPath);
    if (!scriptFile || getFileType(scriptPath).language !== "javascript") return tag;
    const attributes = `${before}${after}`.replace(/\s+src\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+)/i, "");
    return `<script${attributes}>\n${escapeScriptEnd(scriptFile.content)}\n</script>`;
  });

  result = result.replace(/<img\b[^>]*>/gi, tag => {
    const reference = findAttribute(tag, "src");
    const imagePath = reference && resolveLocalPath(htmlPath, reference);
    const imageFile = imagePath && fileMap.get(imagePath);
    const data = imageFile && isImagePath(imagePath) ? asImageData(imageFile) : null;
    if (!reference || !data) return tag;
    const attributePattern = /\bsrc\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+)/i;
    return attributePattern.test(tag) ? tag.replace(attributePattern, `src="${data.replace(/"/g, "&quot;")}"`) : tag;
  });

  result = result.replace(/<style\b([^>]*)>([\s\S]*?)<\/style\s*>/gi, (_tag, attributes: string, content: string) =>
    `<style${attributes}>${inlineCss(content, htmlPath, fileMap)}</style>`,
  );
  result = result.replace(/\bstyle\s*=\s*("([^"]*)"|'([^']*)')/gi, (attribute, wrapped: string, doubleQuoted: string, singleQuoted: string) => {
    const css = doubleQuoted ?? singleQuoted ?? "";
    return attribute.replace(wrapped, `"${inlineCss(css, htmlPath, fileMap).replace(/"/g, "&quot;")}"`);
  });
  return result;
}

function injectDocumentPolicy(html: string): string {
  if (/<head\b[^>]*>/i.test(html)) return html.replace(/<head\b[^>]*>/i, match => `${match}${CSP}`);
  if (/<html\b[^>]*>/i.test(html)) return html.replace(/<html\b[^>]*>/i, match => `${match}<head>${CSP}</head>`);
  return `<!doctype html><html><head><meta charset="utf-8">${CSP}</head><body>${html}</body></html>`;
}

export function buildWebPreviewDocument(files: PreviewFile[], activePath: string | null): { document: string; entryPath: string } {
  const fileMap = new Map(files.filter(file => file.kind !== "folder").map(file => [normalizePath(file.path), file]));
  const htmlFiles = [...fileMap.values()].filter(file => ["html", "htm"].includes(file.path.split(".").at(-1)?.toLowerCase() ?? ""));
  const active = activePath ? fileMap.get(normalizePath(activePath)) : undefined;

  if (active && getFileType(active.path).category === "image") {
    const data = asImageData(active);
    const page = data
      ? `<main style="min-height:100vh;display:grid;place-items:center;background:#111;padding:24px"><img src="${data.replace(/"/g, "&quot;")}" alt="${active.path.replace(/[&"<]/g, "")}" style="max-width:100%;max-height:calc(100vh - 48px);object-fit:contain"></main>`
      : `<p>Could not preview this image file.</p>`;
    return { document: injectDocumentPolicy(page), entryPath: active.path };
  }

  const preferredHtml = active && ["html", "htm"].includes(active.path.split(".").at(-1)?.toLowerCase() ?? "")
    ? active
    : htmlFiles.find(file => /(^|\/)index\.html?$/i.test(file.path)) ?? htmlFiles[0];

  let html = preferredHtml?.content ?? "";
  let entryPath = preferredHtml?.path ?? active?.path ?? "preview.html";
  if (!preferredHtml) {
    const activeLanguage = active ? getFileType(active.path).language : "text";
    const style = active && activeLanguage === "css" ? `<style>${inlineCss(active.content, active.path, fileMap)}</style>` : "";
    const script = active && activeLanguage === "javascript" ? `<script>${escapeScriptEnd(active.content)}</script>` : "";
    html = `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">${style}</head><body>${script || `<main style="font:14px system-ui;color:#bbb;padding:24px">Create an HTML file to build a page preview.</main>`}</body></html>`;
  } else if (active && active.id !== preferredHtml.id) {
    const activeLanguage = getFileType(active.path).language;
    if (activeLanguage === "css" && !hasReferenceTo(html, "link", "href", active.path, entryPath)) {
      const addition = `<style data-vortex-active-file>${inlineCss(active.content, active.path, fileMap)}</style>`;
      html = /<\/head\s*>/i.test(html) ? html.replace(/<\/head\s*>/i, `${addition}</head>`) : `${addition}${html}`;
    } else if (activeLanguage === "javascript" && !hasReferenceTo(html, "script", "src", active.path, entryPath)) {
      const addition = `<script data-vortex-active-file>${escapeScriptEnd(active.content)}</script>`;
      html = /<\/body\s*>/i.test(html) ? html.replace(/<\/body\s*>/i, `${addition}</body>`) : `${html}${addition}`;
    }
  }

  html = inlineLocalAssets(html, entryPath, fileMap);
  return { document: injectDocumentPolicy(html), entryPath };
}
