import JSZip from "jszip";
import { dataUrlToBytes, getImageMimeType, isImagePath } from "@/lib/file-types";

export type ProjectFile = {
  id: string;
  path: string;
  kind: "file" | "folder";
  content: string;
  createdAt: number;
  updatedAt: number;
};

export type Project = {
  id: string;
  name: string;
  description?: string;
  icon?: string;
  color?: string;
  files: ProjectFile[];
  activeFileId: string;
  openFileIds: string[];
  installedPackages: string[];
  envVars: Record<string, string>;
  createdAt: number;
  updatedAt: number;
  lastOpenedAt: number;
};

export type ProjectTemplate =
  | "empty"
  | "hello-world"
  | "cli"
  | "data-analysis"
  | "api-client"
  | "networking"
  | "learning";

export type NewProjectOptions = {
  template?: ProjectTemplate;
  initialFileName?: string;
  description?: string;
  color?: string;
  icon?: string;
  includeReadme?: boolean;
};

export const PROJECT_TEMPLATES: Array<{ id: ProjectTemplate; name: string; description: string }> = [
  { id: "empty", name: "Empty Python project", description: "A clean starting file and nothing extra." },
  { id: "hello-world", name: "Hello World", description: "A small first script ready to run." },
  { id: "cli", name: "CLI application", description: "Argument parsing with a useful command-line entry point." },
  { id: "data-analysis", name: "Data analysis", description: "Explore a small dataset using Python's standard library." },
  { id: "api-client", name: "API client", description: "A standard-library HTTP client starter." },
  { id: "networking", name: "Networking utilities", description: "URL parsing and request helpers; network access depends on Pyodide/browser support." },
  { id: "learning", name: "Python learning project", description: "A small set of editable beginner exercises." },
];

const DATABASE_NAME = "vortex-python-ide";
const DATABASE_VERSION = 1;
const PROJECTS_STORE = "projects";

function database(): Promise<IDBDatabase> {
  if (!("indexedDB" in globalThis)) {
    return Promise.reject(new Error("This browser does not support local project storage."));
  }
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DATABASE_NAME, DATABASE_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(PROJECTS_STORE)) {
        db.createObjectStore(PROJECTS_STORE, { keyPath: "id" });
      }
    };
    request.onsuccess = () => {
      const db = request.result;
      db.onversionchange = () => db.close();
      resolve(db);
    };
    request.onerror = () => reject(request.error ?? new Error("Could not open local project storage."));
    request.onblocked = () => reject(new Error("Project storage is busy in another VORTEX tab. Close the other tab and retry."));
  });
}

function storageError(error: unknown): Error {
  if (error instanceof DOMException && error.name === "QuotaExceededError") {
    return new Error("Local browser storage is full. Export a ZIP backup, then remove projects or files you no longer need.");
  }
  return error instanceof Error ? error : new Error("Local project storage failed.");
}

async function withStore<T>(
  mode: IDBTransactionMode,
  action: (store: IDBObjectStore) => IDBRequest<T>,
): Promise<T> {
  const db = await database();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(PROJECTS_STORE, mode);
    const request = action(transaction.objectStore(PROJECTS_STORE));
    let result: T;
    let settled = false;
    const fail = (error: unknown) => {
      if (settled) return;
      settled = true;
      db.close();
      reject(storageError(error));
    };
    request.onsuccess = () => { result = request.result; };
    request.onerror = () => fail(request.error ?? new Error("Project storage request failed."));
    transaction.onabort = () => fail(transaction.error ?? new Error("Project storage transaction failed."));
    transaction.onerror = () => fail(transaction.error ?? new Error("Project storage transaction failed."));
    transaction.oncomplete = () => {
      if (settled) return;
      settled = true;
      db.close();
      resolve(result);
    };
  });
}

export function normalizeProjectPath(path: string): string {
  const normalized = path.replaceAll("\\", "/");
  if (normalized.startsWith("/")) {
    throw new Error("Project paths must be relative.");
  }
  const parts = normalized.split("/").filter(Boolean);
  if (
    parts.length === 0 ||
    parts.some((part) => part === "." || part === ".." || part.includes("\0"))
  ) {
    throw new Error("Use a valid project-relative file path.");
  }
  return parts.join("/");
}

export async function listProjects(): Promise<Project[]> {
  const projects = await withStore("readonly", (store) => store.getAll());
  return projects.sort((a, b) => b.lastOpenedAt - a.lastOpenedAt);
}

export async function getProject(id: string): Promise<Project | undefined> {
  return withStore("readonly", (store) => store.get(id));
}

export async function saveProject(project: Project): Promise<void> {
  await withStore("readwrite", (store) => store.put(project));
}

export async function saveProjects(projects: Project[]): Promise<void> {
  if (!projects.length) return;
  const db = await database();
  await new Promise<void>((resolve, reject) => {
    const transaction = db.transaction(PROJECTS_STORE, "readwrite");
    const store = transaction.objectStore(PROJECTS_STORE);
    for (const project of projects) store.put(project);
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(storageError(transaction.error));
    transaction.onabort = () => reject(storageError(transaction.error));
  }).finally(() => db.close());
}

export async function deleteProject(id: string): Promise<void> {
  await withStore("readwrite", (store) => store.delete(id));
}

function starterSource(template: ProjectTemplate): string {
  switch (template) {
    case "hello-world":
      return 'def main():\n    print("Hello, world!")\n\n\nif __name__ == "__main__":\n    main()\n';
    case "cli":
      return 'import argparse\n\n\ndef main():\n    parser = argparse.ArgumentParser(description="A small Python command-line app")\n    parser.add_argument("--name", default="VORTEX", help="Name to greet")\n    args = parser.parse_args()\n    print(f"Hello, {args.name}!")\n\n\nif __name__ == "__main__":\n    main()\n';
    case "data-analysis":
      return 'import csv\nimport statistics\nfrom io import StringIO\n\nsample = """day,visitors\nMon,18\nTue,24\nWed,21\nThu,32\nFri,29\n"""\nrows = list(csv.DictReader(StringIO(sample)))\nvisitors = [int(row["visitors"]) for row in rows]\nprint(f"Average visitors: {statistics.mean(visitors):.1f}")\nprint(f"Peak day: {max(rows, key=lambda row: int(row[\'visitors\']))[\'day\']}")\n';
    case "api-client":
      return 'from urllib.request import Request, urlopen\n\n\ndef fetch_json(url: str) -> bytes:\n    """Fetch JSON from an API that permits browser-origin requests."""\n    request = Request(url, headers={"Accept": "application/json", "User-Agent": "VORTEX-Python-IDE"})\n    with urlopen(request, timeout=10) as response:\n        return response.read()\n\n\nif __name__ == "__main__":\n    print("Set an API URL in fetch_json() to try this client.")\n    print("Some services block browser-origin requests.")\n';
    case "networking":
      return 'from urllib.parse import urlparse\n\n\ndef inspect_url(value: str) -> dict[str, str]:\n    parsed = urlparse(value)\n    return {\n        "scheme": parsed.scheme or "—",\n        "host": parsed.netloc or "—",\n        "path": parsed.path or "/",\n    }\n\n\nif __name__ == "__main__":\n    address = "https://example.com/docs?source=vortex"\n    print(inspect_url(address))\n    print("VORTEX runs Pyodide in your browser; socket and OS-level networking are unavailable.")\n';
    case "learning":
      return '"""A place to practice Python one small step at a time."""\n\n\ndef describe_number(value: int) -> str:\n    if value % 2 == 0:\n        return f"{value} is even"\n    return f"{value} is odd"\n\n\nfor number in range(1, 6):\n    print(describe_number(number))\n';
    case "empty":
    default:
      return "";
  }
}

export function makeProject(name: string, options: NewProjectOptions = {}): Project {
  const now = Date.now();
  const id = crypto.randomUUID();
  const projectName = name.trim() || "Untitled project";
  const template = options.template ?? "empty";
  const initialFileName = options.initialFileName?.trim() || "main.py";
  const initialPath = normalizeProjectPath(/\.[a-z\d]+$/i.test(initialFileName) ? initialFileName : `${initialFileName}.py`);
  const extension = initialPath.split(".").at(-1)?.toLowerCase() ?? "py";
  const safeProjectTitle = projectName.replace(/[&<>"']/g, character => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;",
  })[character] ?? character);
  const languageStarters: Record<string, string> = {
    html: `<!doctype html>\n<html lang="en">\n<head>\n  <meta charset="utf-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1">\n  <title>${safeProjectTitle}</title>\n</head>\n<body>\n  <h1>Hello, world!</h1>\n  <script src="script.js"></script>\n</body>\n</html>\n`,
    htm: `<!doctype html>\n<html lang="en">\n<head>\n  <meta charset="utf-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1">\n  <title>${safeProjectTitle}</title>\n</head>\n<body>\n  <h1>Hello, world!</h1>\n</body>\n</html>\n`,
    css: "/* Add your styles here */\n",
    scss: "/* Add your styles here */\n",
    less: "/* Add your styles here */\n",
    js: 'console.log("Hello, world!");\n',
    mjs: 'console.log("Hello, world!");\n',
    cjs: 'console.log("Hello, world!");\n',
    jsx: 'export default function App() { return <main>Hello, world!</main>; }\n',
    ts: 'const message: string = "Hello, world!";\nconsole.log(message);\n',
    tsx: 'export default function App() { return <main>Hello, world!</main>; }\n',
    c: '#include <stdio.h>\n\nint main(void) {\n    printf("Hello, world!\\\\n");\n    return 0;\n}\n',
    cpp: '#include <iostream>\n\nint main() {\n    std::cout << "Hello, world!" << std::endl;\n    return 0;\n}\n',
    cc: '#include <iostream>\n\nint main() {\n    std::cout << "Hello, world!" << std::endl;\n    return 0;\n}\n',
    java: 'class Main {\n    public static void main(String[] args) {\n        System.out.println("Hello, world!");\n    }\n}\n',
    go: 'package main\n\nimport "fmt"\n\nfunc main() {\n    fmt.Println("Hello, world!")\n}\n',
    rs: 'fn main() {\n    println!("Hello, world!");\n}\n',
    rb: 'puts "Hello, world!"\n',
    php: '<?php\necho "Hello, world!";\n',
    cs: 'using System;\n\nclass Program {\n    static void Main() => Console.WriteLine("Hello, world!");\n}\n',
    sh: '#!/usr/bin/env sh\necho "Hello, world!"\n',
    py: starterSource(template),
    pyw: starterSource(template),
    pyi: starterSource(template),
  };
  const initialContent = languageStarters[extension] ?? "";
  const mainId = crypto.randomUUID();
  const files: ProjectFile[] = initialPath.split("/").slice(0, -1).map((_, index, parents) => {
    const path = parents.slice(0, index + 1).join("/");
    return {
      id: crypto.randomUUID(),
      path,
      kind: "folder",
      content: "",
      createdAt: now,
      updatedAt: now,
    };
  });
  files.push({
    id: mainId,
    path: initialPath,
    kind: "file",
    content: initialContent,
    createdAt: now,
    updatedAt: now,
  });
  if (template === "learning") {
    files.push({
      id: crypto.randomUUID(),
      path: "exercises",
      kind: "folder",
      content: "",
      createdAt: now,
      updatedAt: now,
    }, {
      id: crypto.randomUUID(),
      path: "exercises/strings.py",
      kind: "file",
      content: '"""Exercise: return the word with its first letter capitalized."""\n\n\ndef title_case(word: str) -> str:\n    # Replace this line with your solution.\n    return word\n\n\nprint(title_case("vortex"))\n',
      createdAt: now,
      updatedAt: now,
    });
  }
  if (options.includeReadme) {
    files.push({
      id: crypto.randomUUID(),
      path: "README.md",
      kind: "file",
      content: `# ${projectName}\n\n${options.description?.trim() || "A code project in VORTEX IDE."}\n`,
      createdAt: now,
      updatedAt: now,
    });
  }
  return {
    id,
    name: projectName,
    description: options.description?.trim() || undefined,
    color: options.color || "#A855F7",
    icon: options.icon || "code",
    files,
    activeFileId: mainId,
    openFileIds: [mainId],
    installedPackages: [],
    envVars: {},
    createdAt: now,
    updatedAt: now,
    lastOpenedAt: now,
  };
}

export function duplicateProject(project: Project, requestedName?: string): Project {
  const now = Date.now();
  const idMap = new Map<string, string>(project.files.map((file) => [file.id, crypto.randomUUID()]));
  const files = project.files.map((file) => ({
    ...file,
    id: idMap.get(file.id)!,
    createdAt: now,
    updatedAt: now,
  }));
  return {
    ...project,
    id: crypto.randomUUID(),
    name: requestedName?.trim() || `${project.name} copy`,
    files,
    activeFileId: idMap.get(project.activeFileId) ?? files.find((file) => file.kind === "file")?.id ?? "",
    openFileIds: project.openFileIds.flatMap((fileId) => {
      const copyId = idMap.get(fileId);
      return copyId ? [copyId] : [];
    }),
    createdAt: now,
    updatedAt: now,
    lastOpenedAt: now,
  };
}

export function duplicateProjectFile(project: Project, id: string): Project {
  const source = project.files.find((file) => file.id === id);
  if (!source || source.kind !== "file") throw new Error("Choose a file to duplicate.");
  const dot = source.path.lastIndexOf(".");
  const stem = dot > source.path.lastIndexOf("/") ? source.path.slice(0, dot) : source.path;
  const extension = dot > source.path.lastIndexOf("/") ? source.path.slice(dot) : "";
  let path = `${stem}-copy${extension}`;
  let suffix = 2;
  while (project.files.some((file) => file.path === path)) {
    path = `${stem}-copy-${suffix++}${extension}`;
  }
  const now = Date.now();
  const copy: ProjectFile = { ...source, id: crypto.randomUUID(), path, createdAt: now, updatedAt: now };
  return {
    ...project,
    files: [...project.files, copy],
    activeFileId: copy.id,
    openFileIds: [...new Set([...project.openFileIds, copy.id])],
    updatedAt: now,
  };
}

export async function clearAllProjects(): Promise<void> {
  await withStore("readwrite", (store) => store.clear());
}

export async function exportProjectsBackup(projects: Project[]): Promise<Blob> {
  const zip = new JSZip();
  zip.file("vortex-backup.json", JSON.stringify({
    format: "vortex-project-backup",
    version: 1,
    exportedAt: new Date().toISOString(),
    projects,
  }));
  return zip.generateAsync({ type: "blob", compression: "DEFLATE" });
}

export async function importProjectsBackup(file: File): Promise<Project[]> {
  const zip = await JSZip.loadAsync(file);
  const manifest = zip.file("vortex-backup.json");
  if (!manifest) throw new Error("This file is not a VORTEX projects backup.");
  const parsed: unknown = JSON.parse(await manifest.async("string"));
  if (!parsed || typeof parsed !== "object" || !("projects" in parsed) || !Array.isArray(parsed.projects)) {
    throw new Error("The VORTEX backup manifest is invalid.");
  }
  const imported: Project[] = [];
  for (const value of parsed.projects) {
    if (!value || typeof value !== "object") continue;
    const source = value as Partial<Project>;
    if (typeof source.name !== "string" || !Array.isArray(source.files)) continue;
    const files: ProjectFile[] = [];
    const now = Date.now();
    for (const candidate of source.files) {
      if (!candidate || typeof candidate !== "object") continue;
      const entry = candidate as Partial<ProjectFile>;
      if (typeof entry.path !== "string" || (entry.kind !== "file" && entry.kind !== "folder")) continue;
      const path = normalizeProjectPath(entry.path);
      files.push({
        id: crypto.randomUUID(),
        path,
        kind: entry.kind,
        content: entry.kind === "file" && typeof entry.content === "string" ? entry.content : "",
        createdAt: now,
        updatedAt: now,
      });
    }
    const main = files.find((entry) => entry.path === "main.py" && entry.kind === "file")
      ?? files.find((entry) => entry.kind === "file");
    imported.push({
      id: crypto.randomUUID(),
      name: source.name.trim() || "Restored project",
      description: typeof source.description === "string" ? source.description : undefined,
      color: typeof source.color === "string" ? source.color : "#A855F7",
      icon: typeof source.icon === "string" ? source.icon : "code",
      files,
      activeFileId: main?.id ?? "",
      openFileIds: main ? [main.id] : [],
      installedPackages: Array.isArray(source.installedPackages)
        ? source.installedPackages.filter((entry): entry is string => typeof entry === "string")
        : [],
      envVars: source.envVars && typeof source.envVars === "object" && !Array.isArray(source.envVars)
        ? Object.fromEntries(Object.entries(source.envVars).filter((entry): entry is [string, string] => typeof entry[1] === "string"))
        : {},
      createdAt: now,
      updatedAt: now,
      lastOpenedAt: now,
    });
  }
  if (!imported.length) throw new Error("This backup contains no restorable projects.");
  return imported;
}

export function addProjectFile(
  project: Project,
  rawPath: string,
  kind: ProjectFile["kind"],
): Project {
  const path = normalizeProjectPath(rawPath);
  if (project.files.some((file) => file.path === path)) {
    throw new Error(`A file or folder already exists at “${path}”.`);
  }
  const parent = path.split("/").slice(0, -1).join("/");
  if (
    parent &&
    !project.files.some((file) => file.path === parent && file.kind === "folder")
  ) {
    throw new Error(`Create the “${parent}” folder first.`);
  }
  const now = Date.now();
  const file: ProjectFile = {
    id: crypto.randomUUID(),
    path,
    kind,
    content: "",
    createdAt: now,
    updatedAt: now,
  };
  return {
    ...project,
    files: [...project.files, file],
    activeFileId: kind === "file" ? file.id : project.activeFileId,
    openFileIds: kind === "file" ? [...new Set([...project.openFileIds, file.id])] : project.openFileIds,
    updatedAt: now,
  };
}

export function renameProjectFile(project: Project, id: string, rawPath: string): Project {
  const target = normalizeProjectPath(rawPath);
  const source = project.files.find((file) => file.id === id);
  if (!source) throw new Error("That file is no longer in this project.");
  if (source.path === target) return project;
  const isInsideSource = (path: string) => path.startsWith(`${source.path}/`);
  const renamed = project.files.map((file) => {
    if (file.id !== id && file.path !== source.path && !isInsideSource(file.path)) return file;
    const newPath = file.id === id ? target : `${target}${file.path.slice(source.path.length)}`;
    if (
      project.files.some(
        (other) =>
          other.id !== id &&
          !isInsideSource(other.path) &&
          other.path === newPath,
      )
    ) {
      throw new Error(`A file or folder already exists at “${newPath}”.`);
    }
    return { ...file, path: newPath, updatedAt: Date.now() };
  });
  const parent = target.split("/").slice(0, -1).join("/");
  if (
    parent &&
    !renamed.some((file) => file.path === parent && file.kind === "folder")
  ) {
    throw new Error(`Create the “${parent}” folder first.`);
  }
  return { ...project, files: renamed, updatedAt: Date.now() };
}

export function removeProjectFile(project: Project, id: string): Project {
  const source = project.files.find((file) => file.id === id);
  if (!source) return project;
  const isRemoved = (file: ProjectFile) =>
    file.id === id || (source.kind === "folder" && file.path.startsWith(`${source.path}/`));
  const files = project.files.filter((file) => !isRemoved(file));
  const removedIds = new Set(project.files.filter(isRemoved).map((file) => file.id));
  const openFileIds = project.openFileIds.filter((fileId) => !removedIds.has(fileId));
  const fallbackFileId =
    openFileIds.at(-1) ?? files.find((file) => file.kind === "file")?.id ?? "";
  const activeFileId = removedIds.has(project.activeFileId) ? fallbackFileId : project.activeFileId;
  const nextOpenFileIds = openFileIds.length
    ? openFileIds
    : fallbackFileId
      ? [fallbackFileId]
      : [];
  return {
    ...project,
    files,
    openFileIds: nextOpenFileIds,
    activeFileId,
    updatedAt: Date.now(),
  };
}

export async function exportProjectZip(project: Project): Promise<Blob> {
  const zip = new JSZip();
  for (const file of project.files) {
    if (file.kind === "folder") zip.folder(file.path);
    else {
      const imageBytes = isImagePath(file.path) ? dataUrlToBytes(file.content) : null;
      zip.file(file.path, imageBytes ?? file.content);
    }
  }
  zip.file("vortex-project.json", JSON.stringify({ name: project.name, version: 1 }, null, 2));
  return zip.generateAsync({ type: "blob", compression: "DEFLATE" });
}

export async function importProjectZip(file: File, nameOverride?: string): Promise<Project> {
  const zip = await JSZip.loadAsync(file);
  const now = Date.now();
  const files: ProjectFile[] = [];
  const archiveEntries = Object.values(zip.files).filter(
    (entry) => !entry.dir && entry.name !== "vortex-project.json",
  );
  const folderPaths = new Set(
    Object.values(zip.files)
      .filter((entry) => entry.dir)
      .map((entry) => normalizeProjectPath(entry.name)),
  );
  for (const entry of archiveEntries) {
    const path = normalizeProjectPath(entry.name);
    const parts = path.split("/");
    for (let i = 1; i < parts.length; i += 1) {
      folderPaths.add(parts.slice(0, i).join("/"));
    }
  }
  const filePaths = new Set(archiveEntries.map((entry) => normalizeProjectPath(entry.name)));
  for (const folderPath of folderPaths) {
    if (filePaths.has(folderPath)) {
      throw new Error(`The archive uses “${folderPath}” as both a file and a folder.`);
    }
  }
  for (const folderPath of folderPaths) {
    files.push({
      id: crypto.randomUUID(),
      path: folderPath,
      kind: "folder",
      content: "",
      createdAt: now,
      updatedAt: now,
    });
  }
  for (const entry of archiveEntries) {
    const path = normalizeProjectPath(entry.name);
    const content = isImagePath(path)
      ? `data:${getImageMimeType(path) ?? "application/octet-stream"};base64,${await entry.async("base64")}`
      : await entry.async("string");
    files.push({
      id: crypto.randomUUID(),
      path,
      kind: "file",
      content,
      createdAt: now,
      updatedAt: now,
    });
  }
  const main = files.find((item) => /^index\.html?$/i.test(item.path))
    ?? files.find((item) => item.path === "main.py")
    ?? files.find((item) => item.kind === "file");
  const name = nameOverride?.trim() || file.name.replace(/\.zip$/i, "") || "Imported project";
  return {
    id: crypto.randomUUID(),
    name,
    files,
    activeFileId: main?.id ?? "",
    openFileIds: main ? [main.id] : [],
    installedPackages: [],
    envVars: {},
    createdAt: now,
    updatedAt: now,
    lastOpenedAt: now,
  };
}
