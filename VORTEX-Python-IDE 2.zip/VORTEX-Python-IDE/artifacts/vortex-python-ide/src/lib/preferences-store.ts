export type AppearanceTheme = "oled" | "graphite" | "midnight" | "cyberpunk" | "light" | "system";

export type IDEPreferences = {
  theme: AppearanceTheme;
  accentColor: string;
  secondaryAccentColor: string;
  editorTheme: "dark" | "light";
  density: "compact" | "comfortable" | "spacious";
  interfaceFontSize: number;
  editorFontFamily: string;
  editorFontSize: number;
  editorLineHeight: number;
  tabWidth: number;
  insertSpaces: boolean;
  wordWrap: boolean;
  lineNumbers: boolean;
  highlightCurrentLine: boolean;
  indentationGuides: boolean;
  bracketMatching: boolean;
  autoCloseBrackets: boolean;
  autoCloseQuotes: boolean;
  minimap: boolean;
  autoSave: boolean;
  autoSaveDelayMs: number;
  confirmCloseUnsaved: boolean;
  restoreOpenTabs: boolean;
  restoreCursorPosition: boolean;
  openRunResultsFullScreen: boolean;
  autoClearOutput: boolean;
  preserveRunHistory: boolean;
  autoScrollOutput: boolean;
  showExecutionTime: boolean;
  timeoutSeconds: number;
  outputFontSize: number;
  defaultProjectTemplate: string;
  defaultInitialFilename: string;
  defaultProjectColor: string;
  confirmBeforeDelete: boolean;
  showHiddenFiles: boolean;
  restoreLastProject: boolean;
  compactCodingToolbar: boolean;
  hapticFeedback: boolean;
  reducedMotion: boolean;
  highContrast: boolean;
  lowPowerMode: boolean;
};

export type RunHistoryEntry = {
  id: string;
  projectId: string;
  projectName: string;
  filePath: string;
  status: "success" | "error" | "stopped";
  output: Array<{ stream: "stdout" | "stderr" | "system"; text: string }>;
  durationMs?: number;
  exitCode?: number;
  createdAt: number;
};

export const DEFAULT_PREFERENCES: IDEPreferences = {
  theme: "oled",
  accentColor: "#A855F7",
  secondaryAccentColor: "#22D3EE",
  editorTheme: "dark",
  density: "comfortable",
  interfaceFontSize: 13,
  editorFontFamily: "IBM Plex Mono",
  editorFontSize: 14,
  editorLineHeight: 1.6,
  tabWidth: 4,
  insertSpaces: true,
  wordWrap: false,
  lineNumbers: true,
  highlightCurrentLine: true,
  indentationGuides: true,
  bracketMatching: true,
  autoCloseBrackets: true,
  autoCloseQuotes: true,
  minimap: false,
  autoSave: true,
  autoSaveDelayMs: 600,
  confirmCloseUnsaved: true,
  restoreOpenTabs: true,
  restoreCursorPosition: true,
  openRunResultsFullScreen: true,
  autoClearOutput: true,
  preserveRunHistory: true,
  autoScrollOutput: true,
  showExecutionTime: true,
  timeoutSeconds: 15,
  outputFontSize: 13,
  defaultProjectTemplate: "empty",
  defaultInitialFilename: "main.py",
  defaultProjectColor: "#A855F7",
  confirmBeforeDelete: true,
  showHiddenFiles: false,
  restoreLastProject: true,
  compactCodingToolbar: true,
  hapticFeedback: false,
  reducedMotion: false,
  highContrast: false,
  lowPowerMode: false,
};

const DATABASE_NAME = "vortex-preferences";
const DATABASE_VERSION = 2;
const PREFERENCES_STORE = "preferences";
const RUN_HISTORY_STORE = "run-history";

type StoredPreferences = { key: "current"; values: Partial<IDEPreferences>; updatedAt: number };

function openDatabase(): Promise<IDBDatabase> {
  if (!("indexedDB" in globalThis)) {
    return Promise.reject(new Error("This browser does not support local settings storage."));
  }

  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DATABASE_NAME, DATABASE_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(PREFERENCES_STORE)) {
        db.createObjectStore(PREFERENCES_STORE, { keyPath: "key" });
      }
      if (!db.objectStoreNames.contains(RUN_HISTORY_STORE)) {
        db.createObjectStore(RUN_HISTORY_STORE, { keyPath: "id" });
      }
    };
    request.onsuccess = () => {
      const db = request.result;
      db.onversionchange = () => db.close();
      resolve(db);
    };
    request.onerror = () => reject(request.error ?? new Error("Could not open settings storage."));
    request.onblocked = () => reject(new Error("Settings storage is busy in another VORTEX tab. Close the other tab and retry."));
  });
}

async function readStoredPreferences(): Promise<StoredPreferences | undefined> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(PREFERENCES_STORE, "readonly");
    const request = transaction.objectStore(PREFERENCES_STORE).get("current") as IDBRequest<StoredPreferences | undefined>;
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("Could not read settings."));
    transaction.oncomplete = () => db.close();
    transaction.onabort = () => {
      db.close();
      reject(transaction.error ?? new Error("Settings could not be read."));
    };
  });
}

export async function loadPreferences(): Promise<IDEPreferences> {
  const stored = await readStoredPreferences();
  return mergePreferences(stored?.values);
}

export async function savePreferences(values: IDEPreferences): Promise<void> {
  const db = await openDatabase();
  await new Promise<void>((resolve, reject) => {
    const transaction = db.transaction(PREFERENCES_STORE, "readwrite");
    transaction.objectStore(PREFERENCES_STORE).put({
      key: "current",
      values,
      updatedAt: Date.now(),
    } satisfies StoredPreferences);
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error ?? new Error("Could not save settings."));
    transaction.onabort = () => reject(transaction.error ?? new Error("Settings were not saved."));
  }).finally(() => db.close());
}

export async function clearPreferences(): Promise<void> {
  const db = await openDatabase();
  await new Promise<void>((resolve, reject) => {
    const transaction = db.transaction(PREFERENCES_STORE, "readwrite");
    transaction.objectStore(PREFERENCES_STORE).delete("current");
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error ?? new Error("Could not reset settings."));
    transaction.onabort = () => reject(transaction.error ?? new Error("Settings were not reset."));
  }).finally(() => db.close());
}

export async function listRunHistory(): Promise<RunHistoryEntry[]> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(RUN_HISTORY_STORE, "readonly");
    const request = transaction.objectStore(RUN_HISTORY_STORE).getAll() as IDBRequest<RunHistoryEntry[]>;
    let result: RunHistoryEntry[] = [];
    request.onsuccess = () => {
      result = request.result;
    };
    request.onerror = () => reject(request.error ?? new Error("Could not read run history."));
    transaction.oncomplete = () => {
      db.close();
      resolve(result.sort((a, b) => b.createdAt - a.createdAt).slice(0, 50));
    };
    transaction.onabort = () => {
      db.close();
      reject(transaction.error ?? new Error("Run history could not be read."));
    };
  });
}

export async function saveRunHistory(entry: RunHistoryEntry): Promise<void> {
  const db = await openDatabase();
  await new Promise<void>((resolve, reject) => {
    const transaction = db.transaction(RUN_HISTORY_STORE, "readwrite");
    const store = transaction.objectStore(RUN_HISTORY_STORE);
    store.put(entry);
    const allRequest = store.getAll() as IDBRequest<RunHistoryEntry[]>;
    allRequest.onsuccess = () => {
      const oldestFirst = allRequest.result.sort((a, b) => a.createdAt - b.createdAt);
      for (const old of oldestFirst.slice(0, Math.max(0, oldestFirst.length - 50))) store.delete(old.id);
    };
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error ?? new Error("Could not save run history."));
    transaction.onabort = () => reject(transaction.error ?? new Error("Run history was not saved."));
  }).finally(() => db.close());
}

export async function clearRunHistory(): Promise<void> {
  const db = await openDatabase();
  await new Promise<void>((resolve, reject) => {
    const transaction = db.transaction(RUN_HISTORY_STORE, "readwrite");
    transaction.objectStore(RUN_HISTORY_STORE).clear();
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error ?? new Error("Could not clear run history."));
    transaction.onabort = () => reject(transaction.error ?? new Error("Run history was not cleared."));
  }).finally(() => db.close());
}

export function exportPreferencesJson(values: IDEPreferences): string {
  return JSON.stringify({ format: "vortex-preferences", version: 1, preferences: values }, null, 2);
}

export function parsePreferencesJson(text: string): IDEPreferences {
  const parsed: unknown = JSON.parse(text);
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
    throw new Error("Settings backup must be a JSON object.");
  }
  const record = parsed as Record<string, unknown>;
  const source = record.preferences && typeof record.preferences === "object" && !Array.isArray(record.preferences)
    ? record.preferences as Record<string, unknown>
    : record;
  return mergePreferences(source);
}

function mergePreferences(source: unknown): IDEPreferences {
  const merged = { ...DEFAULT_PREFERENCES };
  if (!source || typeof source !== "object" || Array.isArray(source)) return merged;
  const values = source as Record<string, unknown>;
  const enums: Partial<Record<keyof IDEPreferences, string[]>> = {
    theme: ["system", "oled", "graphite", "midnight", "cyberpunk", "light"],
    editorTheme: ["dark", "light"],
    density: ["compact", "comfortable", "spacious"],
    editorFontFamily: ["IBM Plex Mono", "ui-monospace", "monospace"],
    defaultProjectTemplate: ["empty", "hello-world", "cli", "data-analysis", "api-client", "networking", "learning"],
  };
  const numberBounds: Partial<Record<keyof IDEPreferences, [number, number]>> = {
    interfaceFontSize: [11, 17],
    editorFontSize: [10, 24],
    editorLineHeight: [1.2, 2],
    tabWidth: [2, 8],
    autoSaveDelayMs: [250, 2000],
    timeoutSeconds: [1, 120],
    outputFontSize: [10, 18],
  };
  for (const key of Object.keys(DEFAULT_PREFERENCES) as (keyof IDEPreferences)[]) {
    const value = values[key];
    if (typeof value !== typeof DEFAULT_PREFERENCES[key]) continue;
    const allowed = enums[key];
    if (allowed && !allowed.includes(value as string)) continue;
    const bounds = numberBounds[key];
    if (bounds && (!Number.isFinite(value) || (value as number) < bounds[0] || (value as number) > bounds[1])) continue;
    if (key === "tabWidth" && ![2, 4, 8].includes(value as number)) continue;
    if (key === "defaultInitialFilename" && (typeof value !== "string" || value.length > 120 || !value.trim())) continue;
    if ((key === "accentColor" || key === "secondaryAccentColor" || key === "defaultProjectColor") && (typeof value !== "string" || !/^#[0-9a-f]{6}$/i.test(value))) continue;
    (merged as Record<keyof IDEPreferences, unknown>)[key] = value;
  }
  return merged;
}

export async function estimateBrowserStorage(): Promise<{ usage?: number; quota?: number } | null> {
  if (!("storage" in navigator) || !navigator.storage?.estimate) return null;
  const estimate = await navigator.storage.estimate();
  return { usage: estimate.usage, quota: estimate.quota };
}

export function formatBytes(bytes: number | undefined): string {
  if (bytes === undefined || !Number.isFinite(bytes)) return "Unavailable";
  if (bytes < 1024) return `${Math.round(bytes)} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
