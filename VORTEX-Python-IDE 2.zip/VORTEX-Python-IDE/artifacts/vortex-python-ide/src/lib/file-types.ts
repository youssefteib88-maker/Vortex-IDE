export type FileCategory = "web" | "image" | "code" | "data" | "document" | "text";
export type EditorLanguage =
  | "python" | "html" | "css" | "javascript" | "typescript" | "cpp" | "c" | "java"
  | "csharp" | "go" | "rust" | "ruby" | "php" | "swift" | "kotlin" | "shell"
  | "sql" | "json" | "markdown" | "xml" | "yaml" | "lua" | "perl" | "powershell"
  | "r" | "scala" | "dart" | "clojure" | "haskell" | "groovy" | "erlang"
  | "fortran" | "pascal" | "vb" | "text";

export type FileTypeInfo = {
  label: string;
  language: EditorLanguage;
  category: FileCategory;
  icon: string;
  color: string;
  previewable: boolean;
};

const textFile: FileTypeInfo = {
  label: "Text",
  language: "text",
  category: "text",
  icon: "text",
  color: "#a1a1aa",
  previewable: false,
};

const definitions: Record<string, FileTypeInfo> = {};

function define(extensions: string[], info: FileTypeInfo) {
  for (const extension of extensions) definitions[extension] = info;
}

define(["py", "pyw", "pyi"], { label: "Python", language: "python", category: "code", icon: "python", color: "#3776ab", previewable: false });
define(["html", "htm"], { label: "HTML", language: "html", category: "web", icon: "html", color: "#e34f26", previewable: true });
define(["css", "scss", "sass", "less"], { label: "CSS", language: "css", category: "web", icon: "css", color: "#1572b6", previewable: true });
define(["js", "mjs", "cjs", "jsx"], { label: "JavaScript", language: "javascript", category: "web", icon: "javascript", color: "#f7df1e", previewable: true });
define(["ts", "mts", "cts", "tsx"], { label: "TypeScript", language: "typescript", category: "code", icon: "typescript", color: "#3178c6", previewable: false });
define(["c", "h"], { label: "C", language: "c", category: "code", icon: "c", color: "#a8b9cc", previewable: false });
define(["cc", "cpp", "cxx", "c+", "hpp", "hh", "hxx"], { label: "C++", language: "cpp", category: "code", icon: "cpp", color: "#00599c", previewable: false });
define(["cs"], { label: "C#", language: "csharp", category: "code", icon: "csharp", color: "#9b4f96", previewable: false });
define(["java"], { label: "Java", language: "java", category: "code", icon: "java", color: "#ed8b00", previewable: false });
define(["go"], { label: "Go", language: "go", category: "code", icon: "go", color: "#00add8", previewable: false });
define(["rs"], { label: "Rust", language: "rust", category: "code", icon: "rust", color: "#dea584", previewable: false });
define(["rb"], { label: "Ruby", language: "ruby", category: "code", icon: "ruby", color: "#cc342d", previewable: false });
define(["php"], { label: "PHP", language: "php", category: "code", icon: "php", color: "#777bb4", previewable: false });
define(["swift"], { label: "Swift", language: "swift", category: "code", icon: "swift", color: "#f05138", previewable: false });
define(["kt", "kts"], { label: "Kotlin", language: "kotlin", category: "code", icon: "kotlin", color: "#7f52ff", previewable: false });
define(["sh", "bash", "zsh"], { label: "Shell", language: "shell", category: "code", icon: "shell", color: "#4eaa25", previewable: false });
define(["lua"], { label: "Lua", language: "lua", category: "code", icon: "lua", color: "#000080", previewable: false });
define(["pl", "pm"], { label: "Perl", language: "perl", category: "code", icon: "perl", color: "#39457e", previewable: false });
define(["ps1", "psm1"], { label: "PowerShell", language: "powershell", category: "code", icon: "powershell", color: "#5391fe", previewable: false });
define(["r"], { label: "R", language: "r", category: "code", icon: "r", color: "#276dc3", previewable: false });
define(["scala"], { label: "Scala", language: "scala", category: "code", icon: "scala", color: "#dc322f", previewable: false });
define(["dart"], { label: "Dart", language: "dart", category: "code", icon: "dart", color: "#0175c2", previewable: false });
define(["clj", "cljs", "cljc"], { label: "Clojure", language: "clojure", category: "code", icon: "clojure", color: "#63b132", previewable: false });
define(["hs", "lhs"], { label: "Haskell", language: "haskell", category: "code", icon: "haskell", color: "#5e5086", previewable: false });
define(["groovy", "gradle"], { label: "Groovy", language: "groovy", category: "code", icon: "groovy", color: "#4298b8", previewable: false });
define(["erl", "hrl"], { label: "Erlang", language: "erlang", category: "code", icon: "erlang", color: "#a90533", previewable: false });
define(["f", "for", "f90", "f95"], { label: "Fortran", language: "fortran", category: "code", icon: "fortran", color: "#734f96", previewable: false });
define(["pas"], { label: "Pascal", language: "pascal", category: "code", icon: "pascal", color: "#e3f171", previewable: false });
define(["vb"], { label: "Visual Basic", language: "vb", category: "code", icon: "vb", color: "#945db7", previewable: false });
define(["sql"], { label: "SQL", language: "sql", category: "code", icon: "sql", color: "#e38c00", previewable: false });
define(["json", "jsonc"], { label: "JSON", language: "json", category: "data", icon: "json", color: "#eab308", previewable: false });
define(["md", "markdown", "mdx"], { label: "Markdown", language: "markdown", category: "text", icon: "markdown", color: "#8b8b8b", previewable: false });
define(["xml", "xhtml"], { label: "XML", language: "xml", category: "code", icon: "xml", color: "#e37933", previewable: false });
define(["yaml", "yml"], { label: "YAML", language: "yaml", category: "data", icon: "yaml", color: "#cb171e", previewable: false });
define(["toml"], { label: "TOML", language: "text", category: "data", icon: "text", color: "#9c7b52", previewable: false });
define(["png"], { label: "PNG image", language: "text", category: "image", icon: "image", color: "#a78bfa", previewable: true });
define(["jpg", "jpeg"], { label: "JPEG image", language: "text", category: "image", icon: "image", color: "#a78bfa", previewable: true });
define(["gif"], { label: "GIF image", language: "text", category: "image", icon: "image", color: "#a78bfa", previewable: true });
define(["webp"], { label: "WebP image", language: "text", category: "image", icon: "image", color: "#a78bfa", previewable: true });
define(["avif"], { label: "AVIF image", language: "text", category: "image", icon: "image", color: "#a78bfa", previewable: true });
define(["bmp"], { label: "BMP image", language: "text", category: "image", icon: "image", color: "#a78bfa", previewable: true });
define(["ico"], { label: "Icon image", language: "text", category: "image", icon: "image", color: "#a78bfa", previewable: true });
define(["svg"], { label: "SVG image", language: "xml", category: "image", icon: "image", color: "#f59e0b", previewable: true });
define(["pdf"], { label: "PDF document", language: "text", category: "document", icon: "document", color: "#ef4444", previewable: false });

const imageMimeTypes: Record<string, string> = {
  png: "image/png",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  gif: "image/gif",
  webp: "image/webp",
  avif: "image/avif",
  bmp: "image/bmp",
  ico: "image/x-icon",
  svg: "image/svg+xml",
};

export function getFileType(path: string): FileTypeInfo {
  const basename = path.split("/").at(-1)?.toLowerCase() ?? path.toLowerCase();
  if (basename === "dockerfile" || basename.startsWith("dockerfile.")) {
    return { label: "Docker", language: "text", category: "code", icon: "docker", color: "#2496ed", previewable: false };
  }
  if (basename === "makefile" || basename === "gnu makefile") {
    return { label: "Make", language: "shell", category: "code", icon: "make", color: "#6d9c3f", previewable: false };
  }
  const extension = basename.includes(".") ? basename.split(".").at(-1)! : "";
  return definitions[extension] ?? textFile;
}

export function isImagePath(path: string): boolean {
  return getFileType(path).category === "image";
}

export function getImageMimeType(path: string): string | undefined {
  const extension = path.split("/").at(-1)?.toLowerCase().split(".").at(-1) ?? "";
  return imageMimeTypes[extension];
}

export function isWebPreviewPath(path: string): boolean {
  const info = getFileType(path);
  return info.category === "web" && info.previewable;
}

export function dataUrlToBytes(dataUrl: string): Uint8Array | null {
  const match = dataUrl.match(/^data:[^;,]+;base64,([\s\S]*)$/i);
  if (!match) return null;
  const binary = atob(match[1]);
  return Uint8Array.from(binary, character => character.charCodeAt(0));
}
