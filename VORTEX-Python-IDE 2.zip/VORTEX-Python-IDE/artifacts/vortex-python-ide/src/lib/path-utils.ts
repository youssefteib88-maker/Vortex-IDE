export function safeName(path: string): string {
  return path.split("/").pop() || path;
}
