import { PROJECT_TEMPLATES, type ProjectTemplate } from "@/lib/project-store";

type Props = {
  name: string;
  onNameChange: (value: string) => void;
  template: ProjectTemplate;
  onTemplateChange: (value: ProjectTemplate) => void;
  initialFileName: string;
  onInitialFileNameChange: (value: string) => void;
  description: string;
  onDescriptionChange: (value: string) => void;
  color: string;
  onColorChange: (value: string) => void;
  includeReadme: boolean;
  onIncludeReadmeChange: (value: boolean) => void;
  onEnter: () => void;
};

export function ProjectCreationForm({
  name,
  onNameChange,
  template,
  onTemplateChange,
  initialFileName,
  onInitialFileNameChange,
  description,
  onDescriptionChange,
  color,
  onColorChange,
  includeReadme,
  onIncludeReadmeChange,
  onEnter,
}: Props) {
  return <>
    <p className="muted-copy">Nothing is created until you confirm. Project files stay in this browser and can be exported later.</p>
    <div className="field">
      <label htmlFor="project-name">PROJECT NAME</label>
      <input id="project-name" autoFocus maxLength={80} value={name} onChange={event => onNameChange(event.target.value)} onKeyDown={event => { if (event.key === "Enter") onEnter(); }} placeholder="e.g. Data notebook" data-testid="project-name-input" />
    </div>
    <div className="field">
      <label>STARTING TEMPLATE</label>
      <div className="template-grid">
        {PROJECT_TEMPLATES.map(option => <button
          type="button"
          key={option.id}
          className={`template-choice ${template === option.id ? "selected" : ""}`}
          onClick={() => onTemplateChange(option.id)}
          aria-pressed={template === option.id}
          data-testid={`template-${option.id}`}
        ><strong>{option.name}</strong><small>{option.description}</small></button>)}
      </div>
    </div>
    <div className="settings-control-grid">
      <div className="field"><label htmlFor="initial-python-file">INITIAL PYTHON FILE</label><input id="initial-python-file" value={initialFileName} onChange={event => onInitialFileNameChange(event.target.value)} placeholder="main.py" data-testid="initial-python-filename" /></div>
      <label className="color-control"><span><strong>Project color</strong><small>Used in local project lists</small></span><input type="color" value={color} onChange={event => onColorChange(event.target.value)} data-testid="new-project-color" /></label>
    </div>
    <div className="field"><label htmlFor="project-description">DESCRIPTION (OPTIONAL)</label><textarea id="project-description" maxLength={240} value={description} onChange={event => onDescriptionChange(event.target.value)} placeholder="What are you building?" data-testid="new-project-description" /></div>
    <label className="preference-toggle"><span className="preference-toggle-copy"><strong>Add a README file</strong><small>Include a short project description in README.md.</small></span><input type="checkbox" checked={includeReadme} onChange={event => onIncludeReadmeChange(event.target.checked)} data-testid="new-project-readme" /></label>
  </>;
}
