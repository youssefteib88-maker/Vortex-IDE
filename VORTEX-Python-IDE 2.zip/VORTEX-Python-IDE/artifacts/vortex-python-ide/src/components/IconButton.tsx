import type { ReactNode } from "react";

type IconButtonProps = {
  title: string;
  testId: string;
  onClick: () => void;
  children: ReactNode;
  className?: string;
  disabled?: boolean;
};

export function IconButton({
  title,
  testId,
  onClick,
  children,
  className = "",
  disabled = false,
}: IconButtonProps) {
  return (
    <button
      type="button"
      title={title}
      aria-label={title}
      data-testid={testId}
      className={`icon-btn ${className}`}
      onClick={onClick}
      disabled={disabled}
    >
      {children}
    </button>
  );
}
