import { useMemo, useState, type CSSProperties } from "react";
import {
  ArrowDownRight,
  ArrowRight,
  Clock3,
  Code2,
  FileCode2,
  Folder,
  FolderPlus,
  HardDrive,
  Info,
  Layers3,
  Plus,
  Search,
  Upload,
  Zap,
} from "lucide-react";
import type { Project } from "@/lib/project-store";
import "./HomeDashboard.css";

type HomeDashboardProps = {
  projects: Project[];
  onOpenProject: (project: Project) => void;
  onCreateProject: () => void;
  onImportProject: () => void;
  onAboutRuntime: () => void;
};

type DashboardTab = "All" | "Recent" | "Create";

const tabs: DashboardTab[] = ["All", "Recent", "Create"];

function formatDate(timestamp: number, emptyLabel = "Not opened yet") {
  if (!timestamp || !Number.isFinite(timestamp)) return emptyLabel;
  return new Intl.DateTimeFormat(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
  }).format(new Date(timestamp));
}

function fileCount(project: Project) {
  return project.files.filter((file) => file.kind === "file").length;
}

function folderCount(project: Project) {
  return project.files.filter((file) => file.kind === "folder").length;
}

function ProjectCard({
  project,
  recent = false,
  onOpen,
}: {
  project: Project;
  recent?: boolean;
  onOpen: (project: Project) => void;
}) {
  const color = project.color || "#a855f7";
  const files = fileCount(project);
  const folders = folderCount(project);

  return (
    <button
      className="vxd-project-card"
      type="button"
      onClick={() => onOpen(project)}
      data-testid={`dashboard-project-${project.id}`}
      aria-label={`Open ${project.name}`}
    >
      <span className="vxd-card-topline">
        <span className="vxd-project-icon" style={{ "--project-color": color } as CSSProperties}>
          <Code2 size={17} strokeWidth={1.8} />
        </span>
        <span className="vxd-card-arrow" aria-hidden="true"><ArrowDownRight size={17} /></span>
      </span>
      <span className="vxd-project-title">{project.name}</span>
      <span className="vxd-project-meta">
        <span>{files} {files === 1 ? "file" : "files"}</span>
        {folders > 0 && <><i /> <span>{folders} {folders === 1 ? "folder" : "folders"}</span></>}
      </span>
      <span className="vxd-card-divider" />
      <span className="vxd-project-date">
        <Clock3 size={12} />
        {recent && project.lastOpenedAt
          ? `Opened ${formatDate(project.lastOpenedAt)}`
          : `Updated ${formatDate(project.updatedAt, "Date unavailable")}`}
      </span>
    </button>
  );
}

export function HomeDashboard({
  projects,
  onOpenProject,
  onCreateProject,
  onImportProject,
  onAboutRuntime,
}: HomeDashboardProps) {
  const [activeTab, setActiveTab] = useState<DashboardTab>("All");
  const [query, setQuery] = useState("");

  const allProjects = useMemo(
    () => [...projects].sort((a, b) => b.updatedAt - a.updatedAt),
    [projects],
  );
  const recentProjects = useMemo(
    () => [...projects].sort((a, b) => b.lastOpenedAt - a.lastOpenedAt),
    [projects],
  );
  const visibleProjects = (activeTab === "Recent" ? recentProjects : allProjects).filter((project) =>
    project.name.toLocaleLowerCase().includes(query.trim().toLocaleLowerCase()),
  );
  const totalFiles = projects.reduce((count, project) => count + fileCount(project), 0);

  return (
    <main className="vxd-shell">
      <header className="vxd-header">
        <div className="vxd-brand">
          <span className="vxd-brand-mark"><Zap size={15} fill="currentColor" /></span>
          <span className="vxd-brand-name">VORTEX <i>PYTHON IDE</i></span>
        </div>
        <div className="vxd-header-spacer" />
        <span className="vxd-local-status"><span /> LOCAL WORKSPACE</span>
        <button className="vxd-icon-action" type="button" onClick={onAboutRuntime} aria-label="About this runtime" data-testid="dashboard-runtime-info">
          <Info size={16} />
        </button>
      </header>

      <div className="vxd-content">
        <section className="vxd-intro" aria-labelledby="vxd-heading">
          <div className="vxd-intro-copy">
            <div className="vxd-kicker"><span /> YOUR WORKSPACE</div>
            <h1 id="vxd-heading">{activeTab === "Create" ? <>Start with a<br /><em>new project.</em></> : <>Back to the<br /><em>workbench.</em></>}</h1>
            <p>{activeTab === "Create"
              ? "Set up a fresh space for the next thing you want to make."
              : "Your code, close at hand. Pick up where you left off."}</p>
          </div>
          <div className="vxd-workspace-stamp" aria-label={`${projects.length} projects and ${totalFiles} files stored locally`}>
            <div className="vxd-stamp-orbit"><span /><span /><span /></div>
            <div className="vxd-stamp-info">
              <span className="vxd-stamp-label">LOCAL INDEX</span>
              <strong>{String(projects.length).padStart(2, "0")} <small>PROJECTS</small></strong>
              <span className="vxd-stamp-sub">{totalFiles} source {totalFiles === 1 ? "file" : "files"} · stored in browser</span>
            </div>
          </div>
        </section>

        <nav className="vxd-tab-rail" aria-label="Project views" role="tablist">
          {tabs.map((tab) => (
            <button
              key={tab}
              type="button"
              role="tab"
              aria-selected={activeTab === tab}
              aria-controls="vxd-tab-panel"
              id={`vxd-tab-${tab.toLowerCase()}`}
              className={`vxd-tab ${activeTab === tab ? "is-active" : ""}`}
              onClick={() => {
                setActiveTab(tab);
                setQuery("");
              }}
              data-testid={`dashboard-tab-${tab.toLowerCase()}`}
            >
              {tab === "All" && <Layers3 size={14} />}
              {tab === "Recent" && <Clock3 size={14} />}
              {tab === "Create" && <Plus size={14} />}
              <span>{tab}</span>
              {tab === "All" && <small>{projects.length}</small>}
            </button>
          ))}
        </nav>

        <section
          className="vxd-panel"
          id="vxd-tab-panel"
          role="tabpanel"
          aria-labelledby={`vxd-tab-${activeTab.toLowerCase()}`}
          key={activeTab}
        >
          {activeTab === "Create" ? (
            <div className="vxd-create-panel">
              <div className="vxd-create-visual" aria-hidden="true">
                <div className="vxd-create-ring vxd-create-ring-one" />
                <div className="vxd-create-ring vxd-create-ring-two" />
                <div className="vxd-create-core"><FolderPlus size={25} strokeWidth={1.5} /></div>
                <span className="vxd-create-spark vxd-spark-one" />
                <span className="vxd-create-spark vxd-spark-two" />
                <span className="vxd-create-spark vxd-spark-three" />
              </div>
              <div className="vxd-create-copy">
                <span className="vxd-section-label">A CLEAN START</span>
                <h2>Make room for<br />a new idea.</h2>
                <p>Create a local project with a starter template, or bring an existing project ZIP into your workspace.</p>
                <div className="vxd-create-actions">
                  <button className="vxd-primary-button" type="button" onClick={onCreateProject} data-testid="dashboard-create-project">
                    <Plus size={15} /> New project <ArrowRight size={14} />
                  </button>
                  <button className="vxd-secondary-button" type="button" onClick={onImportProject} data-testid="dashboard-import-project">
                    <Upload size={14} /> Import project ZIP
                  </button>
                </div>
              </div>
              <div className="vxd-create-foot">
                <HardDrive size={14} />
                <span>Projects stay in this browser. Nothing is sent to a server.</span>
              </div>
            </div>
          ) : (
            <>
              <div className="vxd-list-toolbar">
                <div>
                  <span className="vxd-section-label">{activeTab === "Recent" ? "PICK UP AGAIN" : "PROJECT LIBRARY"}</span>
                  <h2>{activeTab === "Recent" ? "Recently opened" : "All projects"} <small>{visibleProjects.length}</small></h2>
                </div>
                <label className="vxd-search">
                  <Search size={15} />
                  <input
                    type="search"
                    value={query}
                    onChange={(event) => setQuery(event.target.value)}
                    placeholder="Find a project"
                    aria-label="Find a project"
                    data-testid="dashboard-project-search"
                  />
                  <kbd>/</kbd>
                </label>
              </div>

              {visibleProjects.length > 0 ? (
                <div className="vxd-project-grid">
                  {visibleProjects.map((project) => (
                    <ProjectCard
                      key={project.id}
                      project={project}
                      recent={activeTab === "Recent"}
                      onOpen={onOpenProject}
                    />
                  ))}
                  {activeTab === "All" && (
                    <button className="vxd-add-card" type="button" onClick={onCreateProject} data-testid="dashboard-create-project-card">
                      <span><Plus size={18} /></span>
                      <strong>New project</strong>
                      <small>Start with a blank canvas</small>
                    </button>
                  )}
                </div>
              ) : query ? (
                <div className="vxd-empty-state vxd-search-empty">
                  <span className="vxd-empty-icon"><Search size={19} /></span>
                  <div><h3>No matching projects</h3><p>Try another name or clear your search.</p></div>
                  <button className="vxd-text-button" type="button" onClick={() => setQuery("")}>Clear search</button>
                </div>
              ) : projects.length === 0 ? (
                <div className="vxd-empty-state">
                  <span className="vxd-empty-icon"><FileCode2 size={20} /></span>
                  <div>
                    <span className="vxd-section-label">NOTHING HERE YET</span>
                    <h3>{activeTab === "Recent" ? "Your recent work will appear here." : "Your workspace is a blank canvas."}</h3>
                    <p>Create a project or import a ZIP to make this space yours.</p>
                  </div>
                  <div className="vxd-empty-actions">
                    <button className="vxd-primary-button" type="button" onClick={onCreateProject} data-testid="dashboard-create-project">
                      <Plus size={15} /> Create a project
                    </button>
                    <button className="vxd-text-button" type="button" onClick={onImportProject} data-testid="dashboard-import-project">
                      <Upload size={14} /> Import ZIP
                    </button>
                  </div>
                </div>
              ) : (
                <div className="vxd-empty-state">
                  <span className="vxd-empty-icon"><Clock3 size={19} /></span>
                  <div><h3>No recent projects yet</h3><p>Open a project to see it in your recent workspace.</p></div>
                  <button className="vxd-text-button" type="button" onClick={() => setActiveTab("All")}>Browse all projects <ArrowRight size={13} /></button>
                </div>
              )}
            </>
          )}
        </section>

        <footer className="vxd-footer">
          <div><span className="vxd-footer-lock"><Folder size={13} /></span> LOCAL-FIRST <i /> INDEXEDDB STORAGE <i /> NO ACCOUNT REQUIRED</div>
          <button type="button" onClick={onAboutRuntime} data-testid="dashboard-about-runtime">About the runtime <ArrowRight size={12} /></button>
        </footer>
      </div>
    </main>
  );
}

export default HomeDashboard;
