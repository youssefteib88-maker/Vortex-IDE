import { useRef, useState, type ChangeEvent } from "react";
import { Download, HardDrive, Palette, RotateCcw, SlidersHorizontal, Upload } from "lucide-react";
import type { IDEPreferences } from "@/lib/preferences-store";

type SettingsSection = "appearance" | "editor" | "run" | "storage";

type Props = {
  preferences: IDEPreferences;
  onUpdate: (changes: Partial<IDEPreferences>) => void;
  projectCount: number;
  storageUsage: string;
  storageQuota: string;
  onExportProject: () => void;
  onExportBackup: () => void;
  onImportBackup: (file: File) => void;
  onExportPreferences: () => void;
  onImportPreferences: (text: string) => void;
  onResetPreferences: () => void;
  onClearProjects: () => void;
  onOpenRunSettings: () => void;
  onOpenEnvironment: () => void;
  onRenameProject: () => void;
  onImportPython: () => void;
};

const sections: Array<{ id: SettingsSection; label: string; icon: typeof Palette }> = [
  { id: "appearance", label: "Appearance", icon: Palette },
  { id: "editor", label: "Editor", icon: SlidersHorizontal },
  { id: "run", label: "Run & output", icon: RotateCcw },
  { id: "storage", label: "Local data", icon: HardDrive },
];

const themes: Array<{ id: IDEPreferences["theme"]; label: string; color: string }> = [
  { id: "system", label: "System default", color: "#565b67" },
  { id: "oled", label: "OLED black", color: "#08090D" },
  { id: "graphite", label: "Graphite", color: "#17181F" },
  { id: "midnight", label: "Midnight", color: "#0B1020" },
  { id: "cyberpunk", label: "Neon", color: "#090B12" },
  { id: "light", label: "Light", color: "#EEEFF4" },
];

function SettingToggle({ title, detail, checked, onChange, testId }: {
  title: string; detail?: string; checked: boolean; onChange: (checked: boolean) => void; testId: string;
}) {
  return <label className="preference-toggle">
    <span className="preference-toggle-copy"><strong>{title}</strong>{detail && <small>{detail}</small>}</span>
    <input type="checkbox" checked={checked} onChange={(event) => onChange(event.target.checked)} data-testid={testId} />
  </label>;
}

export function SettingsPanel({
  preferences,
  onUpdate,
  projectCount,
  storageUsage,
  storageQuota,
  onExportProject,
  onExportBackup,
  onImportBackup,
  onExportPreferences,
  onImportPreferences,
  onResetPreferences,
  onClearProjects,
  onOpenRunSettings,
  onOpenEnvironment,
  onRenameProject,
  onImportPython,
}: Props) {
  const [section, setSection] = useState<SettingsSection>("appearance");
  const preferenceInput = useRef<HTMLInputElement>(null);
  const backupInput = useRef<HTMLInputElement>(null);

  const importPreferenceFile = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.currentTarget.value = "";
    if (!file) return;
    try { onImportPreferences(await file.text()); }
    catch (error) { window.alert(error instanceof Error ? error.message : "Could not read that preferences file."); }
  };

  return <div className="settings-panel">
    <nav className="settings-sections" aria-label="Settings sections" role="tablist">
      {sections.map(({ id, label, icon: Icon }) => <button
        type="button"
        key={id}
        role="tab"
        aria-selected={section === id}
        className={section === id ? "settings-section active" : "settings-section"}
        onClick={() => setSection(id)}
        data-testid={`settings-tab-${id}`}
      ><Icon size={14} />{label}</button>)}
    </nav>

    <div className="settings-page" role="tabpanel" data-testid={`settings-page-${section}`}>
      {section === "appearance" && <>
        <div className="settings-intro"><strong>Make the workspace yours</strong><span>Theme and display preferences are saved in this browser.</span></div>
        <div className="settings-group">
          <div className="settings-label">COLOR THEME</div>
          <div className="theme-grid">
            {themes.map((theme) => <button
              type="button"
              key={theme.id}
              className={`theme-choice ${preferences.theme === theme.id ? "selected" : ""}`}
              onClick={() => onUpdate({ theme: theme.id })}
              data-testid={`theme-${theme.id}`}
              aria-pressed={preferences.theme === theme.id}
            ><span className="theme-swatch" style={{ background: theme.color }}><i style={{ background: preferences.accentColor }} /><i style={{ background: preferences.secondaryAccentColor }} /></span><span>{theme.label}</span></button>)}
          </div>
        </div>
        <div className="settings-control-grid">
          <label className="color-control"><span><strong>Primary accent</strong><small>Buttons, selection and focus</small></span><input type="color" value={preferences.accentColor} onChange={(event) => onUpdate({ accentColor: event.target.value })} data-testid="setting-accent-color" /></label>
          <label className="color-control"><span><strong>Secondary accent</strong><small>Highlights and status cues</small></span><input type="color" value={preferences.secondaryAccentColor} onChange={(event) => onUpdate({ secondaryAccentColor: event.target.value })} data-testid="setting-secondary-accent-color" /></label>
        </div>
        <div className="field"><label>INTERFACE DENSITY</label><select value={preferences.density} onChange={(event) => onUpdate({ density: event.target.value as IDEPreferences["density"] })} data-testid="setting-density"><option value="compact">Compact</option><option value="comfortable">Comfortable</option><option value="spacious">Spacious</option></select></div>
        <div className="field"><label>INTERFACE TEXT SIZE · {preferences.interfaceFontSize}px</label><input type="range" min="11" max="17" value={preferences.interfaceFontSize} onChange={(event) => onUpdate({ interfaceFontSize: Number(event.target.value) })} data-testid="setting-interface-font-size" /></div>
        <SettingToggle title="Reduce motion" detail="Minimize interface animation." checked={preferences.reducedMotion} onChange={(reducedMotion) => onUpdate({ reducedMotion })} testId="setting-reduced-motion" />
        <SettingToggle title="High contrast" detail="Increase contrast on controls and dividers." checked={preferences.highContrast} onChange={(highContrast) => onUpdate({ highContrast })} testId="setting-high-contrast" />
        <SettingToggle title="Low power mode" detail="Turn off ambient motion and effects." checked={preferences.lowPowerMode} onChange={(lowPowerMode) => onUpdate({ lowPowerMode })} testId="setting-low-power" />
        <SettingToggle title="Compact coding toolbar" detail="Use a tighter editor toolbar layout." checked={preferences.compactCodingToolbar} onChange={(compactCodingToolbar) => onUpdate({ compactCodingToolbar })} testId="setting-compact-toolbar" />
      </>}

      {section === "editor" && <>
        <div className="settings-intro"><strong>Code editor</strong><span>These preferences apply to the CodeMirror editor.</span></div>
        <div className="field"><label>EDITOR FONT</label><select value={preferences.editorFontFamily} onChange={(event) => onUpdate({ editorFontFamily: event.target.value })} data-testid="setting-editor-font"><option value="IBM Plex Mono">IBM Plex Mono</option><option value="ui-monospace">System monospace</option><option value="monospace">Monospace fallback</option></select></div>
        <div className="field"><label>TEXT SIZE · {preferences.editorFontSize}px</label><input type="range" min="10" max="24" value={preferences.editorFontSize} onChange={(event) => onUpdate({ editorFontSize: Number(event.target.value) })} data-testid="setting-font-size" /></div>
        <div className="settings-control-grid">
          <label className="field"><span className="settings-label">INDENT SIZE</span><select value={preferences.tabWidth} onChange={(event) => onUpdate({ tabWidth: Number(event.target.value) })} data-testid="setting-tab-width"><option value={2}>2 spaces</option><option value={4}>4 spaces</option><option value={8}>8 spaces</option></select></label>
          <label className="field"><span className="settings-label">LINE HEIGHT · {preferences.editorLineHeight.toFixed(1)}</span><input type="range" min="1.2" max="2" step="0.1" value={preferences.editorLineHeight} onChange={(event) => onUpdate({ editorLineHeight: Number(event.target.value) })} data-testid="setting-line-height" /></label>
        </div>
        <SettingToggle title="Light editor surface" detail="Use a light syntax editor while keeping the workspace theme." checked={preferences.editorTheme === "light"} onChange={(checked) => onUpdate({ editorTheme: checked ? "light" : "dark" })} testId="setting-editor-theme" />
        <SettingToggle title="Line numbers" checked={preferences.lineNumbers} onChange={(lineNumbers) => onUpdate({ lineNumbers })} testId="setting-line-numbers" />
        <SettingToggle title="Highlight current line" checked={preferences.highlightCurrentLine} onChange={(highlightCurrentLine) => onUpdate({ highlightCurrentLine })} testId="setting-highlight-line" />
        <SettingToggle title="Indentation guides" checked={preferences.indentationGuides} onChange={(indentationGuides) => onUpdate({ indentationGuides })} testId="setting-indentation-guides" />
        <SettingToggle title="Code minimap" detail="Show a compact text overview beside the editor." checked={preferences.minimap} onChange={(minimap) => onUpdate({ minimap })} testId="setting-minimap" />
        <SettingToggle title="Word wrap" checked={preferences.wordWrap} onChange={(wordWrap) => onUpdate({ wordWrap })} testId="setting-word-wrap" />
        <SettingToggle title="Auto-close brackets and quotes" checked={preferences.autoCloseBrackets && preferences.autoCloseQuotes} onChange={(checked) => onUpdate({ autoCloseBrackets: checked, autoCloseQuotes: checked })} testId="setting-auto-close" />
        <SettingToggle title="Insert spaces when indenting" checked={preferences.insertSpaces} onChange={(insertSpaces) => onUpdate({ insertSpaces })} testId="setting-insert-spaces" />
        <SettingToggle title="Save edits automatically" detail={`Wait ${preferences.autoSaveDelayMs} ms after typing.`} checked={preferences.autoSave} onChange={(autoSave) => onUpdate({ autoSave })} testId="setting-autosave" />
        {preferences.autoSave && <div className="field"><label>AUTO-SAVE DELAY · {preferences.autoSaveDelayMs} ms</label><input type="range" min="250" max="2000" step="50" value={preferences.autoSaveDelayMs} onChange={(event) => onUpdate({ autoSaveDelayMs: Number(event.target.value) })} data-testid="setting-autosave-delay" /></div>}
        <SettingToggle title="Restore open tabs" detail="Reopen the last files for the current project." checked={preferences.restoreOpenTabs} onChange={(restoreOpenTabs) => onUpdate({ restoreOpenTabs })} testId="setting-restore-tabs" />
        <SettingToggle title="Restore cursor position" detail="Return to the last editing position in each file." checked={preferences.restoreCursorPosition} onChange={(restoreCursorPosition) => onUpdate({ restoreCursorPosition })} testId="setting-restore-cursor" />
        <SettingToggle title="Confirm before closing unsaved files" checked={preferences.confirmCloseUnsaved} onChange={(confirmCloseUnsaved) => onUpdate({ confirmCloseUnsaved })} testId="setting-confirm-close-unsaved" />
      </>}

      {section === "run" && <>
        <div className="settings-intro"><strong>Run & output</strong><span>Python executes locally in an isolated Pyodide browser runtime.</span></div>
        <SettingToggle title="Open results by default" detail="Start in the full-height output view on small screens." checked={preferences.openRunResultsFullScreen} onChange={(openRunResultsFullScreen) => onUpdate({ openRunResultsFullScreen })} testId="setting-results-fullscreen" />
        <SettingToggle title="Clear output before each run" checked={preferences.autoClearOutput} onChange={(autoClearOutput) => onUpdate({ autoClearOutput })} testId="setting-clear-output" />
        <SettingToggle title="Scroll to new output" checked={preferences.autoScrollOutput} onChange={(autoScrollOutput) => onUpdate({ autoScrollOutput })} testId="setting-auto-scroll" />
        <SettingToggle title="Keep recent run history" detail="Store the latest 50 run summaries and output in this browser." checked={preferences.preserveRunHistory} onChange={(preserveRunHistory) => onUpdate({ preserveRunHistory })} testId="setting-run-history" />
        <SettingToggle title="Show execution duration" checked={preferences.showExecutionTime} onChange={(showExecutionTime) => onUpdate({ showExecutionTime })} testId="setting-execution-time" />
        <div className="field"><label>DEFAULT EXECUTION TIMEOUT · {preferences.timeoutSeconds}s</label><input type="range" min="1" max="120" value={preferences.timeoutSeconds} onChange={(event) => onUpdate({ timeoutSeconds: Number(event.target.value) })} data-testid="setting-default-timeout" /></div>
        <div className="field"><label>OUTPUT TEXT SIZE · {preferences.outputFontSize}px</label><input type="range" min="10" max="18" value={preferences.outputFontSize} onChange={(event) => onUpdate({ outputFontSize: Number(event.target.value) })} data-testid="setting-output-font-size" /></div>
        <button className="secondary-btn" type="button" onClick={onOpenRunSettings} data-testid="open-run-config">Script arguments and environment variables <Download size={13} /></button>
        <p className="muted-copy">This is not Linux, Bash, or a server-backed Python service. Package support depends on Pyodide-compatible wheels.</p>
      </>}

      {section === "storage" && <>
        <div className="settings-intro"><strong>Local data & backups</strong><span>Projects and preferences stay on this device unless you export them.</span></div>
        <div className="storage-stats">
          <div><span>PROJECTS</span><strong>{projectCount}</strong></div>
          <div><span>ESTIMATED BROWSER STORAGE</span><strong>{storageUsage}</strong></div>
          <div><span>AVAILABLE BROWSER QUOTA</span><strong>{storageQuota}</strong></div>
        </div>
        <div className="settings-intro"><strong>New project defaults</strong><span>Used each time you start a project.</span></div>
        <div className="field"><label>STARTING TEMPLATE</label><select value={preferences.defaultProjectTemplate} onChange={(event) => onUpdate({ defaultProjectTemplate: event.target.value })} data-testid="setting-default-template"><option value="empty">Empty project</option><option value="hello-world">Hello World</option><option value="cli">Command-line app</option><option value="data-analysis">Data analysis</option><option value="api-client">API client</option><option value="networking">Networking</option><option value="learning">Python learning</option></select></div>
        <div className="settings-control-grid">
          <div className="field"><label>INITIAL PYTHON FILE</label><input value={preferences.defaultInitialFilename} onChange={(event) => onUpdate({ defaultInitialFilename: event.target.value })} data-testid="setting-default-filename" /></div>
          <label className="color-control"><span><strong>New project color</strong><small>Default project accent</small></span><input type="color" value={preferences.defaultProjectColor} onChange={(event) => onUpdate({ defaultProjectColor: event.target.value })} data-testid="setting-default-project-color" /></label>
        </div>
        <SettingToggle title="Restore the last project" detail="Otherwise show recent projects when VORTEX opens." checked={preferences.restoreLastProject} onChange={(restoreLastProject) => onUpdate({ restoreLastProject })} testId="setting-restore-project" />
        <SettingToggle title="Show hidden files" detail="Include dotfiles such as .gitignore in the explorer." checked={preferences.showHiddenFiles} onChange={(showHiddenFiles) => onUpdate({ showHiddenFiles })} testId="setting-show-hidden" />
        <SettingToggle title="Confirm before deleting files or projects" checked={preferences.confirmBeforeDelete} onChange={(confirmBeforeDelete) => onUpdate({ confirmBeforeDelete })} testId="setting-confirm-delete" />
        <SettingToggle title="Haptic feedback" detail="Use a short vibration on supported devices." checked={preferences.hapticFeedback} onChange={(hapticFeedback) => onUpdate({ hapticFeedback })} testId="setting-haptics" />
        <div className="settings-action-grid">
          <button className="secondary-btn" type="button" onClick={onExportProject} data-testid="backup-current-project"><Download size={14} /> Export this project</button>
          <button className="secondary-btn" type="button" onClick={onExportBackup} data-testid="backup-all-projects"><Download size={14} /> Back up all projects</button>
          <button className="secondary-btn" type="button" onClick={() => backupInput.current?.click()} data-testid="restore-all-projects"><Upload size={14} /> Restore project backup</button>
          <button className="secondary-btn" type="button" onClick={onExportPreferences} data-testid="export-preferences"><Download size={14} /> Export preferences</button>
          <button className="secondary-btn" type="button" onClick={() => preferenceInput.current?.click()} data-testid="import-preferences"><Upload size={14} /> Import preferences</button>
          <button className="secondary-btn" type="button" onClick={onImportPython} data-testid="settings-import-python"><Upload size={14} /> Import a .py file</button>
          <button className="secondary-btn" type="button" onClick={onOpenEnvironment} data-testid="open-env-vars">Environment variables</button>
          <button className="secondary-btn" type="button" onClick={onRenameProject} data-testid="settings-rename-project">Rename project</button>
        </div>
        <div className="settings-danger-zone">
          <div><strong>Reset preferences</strong><small>Restore VORTEX's default appearance and editor options.</small></div>
          <button className="secondary-btn" type="button" onClick={onResetPreferences} data-testid="reset-preferences">Reset</button>
        </div>
        <div className="settings-danger-zone">
          <div><strong>Delete every project</strong><small>Remove {projectCount} projects and their files from this browser. This cannot be undone.</small></div>
          <button className="secondary-btn danger" type="button" onClick={onClearProjects} data-testid="clear-all-projects">Delete all</button>
        </div>
        <input ref={backupInput} type="file" accept=".zip,application/zip" hidden onChange={(event) => { const file = event.target.files?.[0]; event.currentTarget.value = ""; if (file) onImportBackup(file); }} data-testid="project-backup-input" />
        <input ref={preferenceInput} type="file" accept=".json,application/json" hidden onChange={(event) => { void importPreferenceFile(event); }} data-testid="preferences-import-input" />
      </>}
    </div>
  </div>;
}
