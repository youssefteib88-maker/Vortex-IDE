import { useMemo, useState } from "react";
import {
  ChevronDown,
  ChevronRight,
  Download,
  File as FileIcon,
  FileCode2,
  FileJson,
  FilePlus2,
  Folder,
  FolderPlus,
  FolderTree,
  MoreHorizontal,
  PanelLeftClose,
  Search as SearchIcon,
  Trash2,
  Upload,
} from "lucide-react";
import type { Project, ProjectFile } from "@/lib/project-store";
import { safeName } from "@/lib/path-utils";
import { IconButton } from "./IconButton";

const ICON_SIZE = 14;

type ExplorerProps = {
  project: Project;
  collapsed: boolean;
  activeId: string;
  onSelect: (file: ProjectFile) => void;
  onToggle: () => void;
  onCreate: (kind: "file" | "folder", folderPath?: string) => void;
  onRename: (file: ProjectFile) => void;
  onDelete: (file: ProjectFile) => void;
  onImport: () => void;
  onImportPy: () => void;
  onExport: () => void;
};

export function Explorer({
  project,
  collapsed,
  activeId,
  onSelect,
  onToggle,
  onCreate,
  onRename,
  onDelete,
  onImport,
  onImportPy,
  onExport,
}: ExplorerProps) {
  const [folded, setFolded] = useState<Set<string>>(new Set());
  const [filter, setFilter] = useState("");
  const visible = useMemo(() => {
    const match = filter.trim().toLowerCase();
    return project.files
      .filter((file) => !match || file.path.toLowerCase().includes(match))
      .sort((a, b) => {
        const aa = a.path.split("/");
        const bb = b.path.split("/");
        if (aa.length !== bb.length) return aa.length - bb.length;
        return a.kind === b.kind
          ? aa.at(-1)!.localeCompare(bb.at(-1)!)
          : a.kind === "folder"
            ? -1
            : 1;
      })
      .filter((file) => {
        const ancestors = file.path.split("/").slice(0, -1);
        let parent = "";
        for (const part of ancestors) {
          parent = parent ? `${parent}/${part}` : part;
          if (folded.has(parent) && !match) return false;
        }
        return true;
      });
  }, [project.files, folded, filter]);

  return (
    <aside className={`explorer ${collapsed ? "collapsed" : ""}`} data-testid="project-explorer">
      <div className="panel-head">
        <span>EXPLORER</span>
        <div className="file-tools">
          <IconButton title="New Python file" testId="new-file" onClick={() => onCreate("file")}>
            <FilePlus2 size={ICON_SIZE} />
          </IconButton>
          <IconButton title="New folder" testId="new-folder" onClick={() => onCreate("folder")}>
            <FolderPlus size={ICON_SIZE} />
          </IconButton>
          <IconButton title="Import or export project" testId="project-files-menu" onClick={onExport}>
            <MoreHorizontal size={ICON_SIZE} />
          </IconButton>
          <IconButton title="Collapse explorer" testId="collapse-explorer" onClick={onToggle}>
            <PanelLeftClose size={ICON_SIZE} />
          </IconButton>
        </div>
      </div>
      <div className="explorer-project">
        <FolderTree size={14} color="#168bff" />
        <span>{project.name.toUpperCase()}</span>
      </div>
      <div style={{ padding: "2px 10px 8px", display: "flex", gap: 6 }}>
        <div style={{ position: "relative", flex: 1 }}>
          <SearchIcon size={12} style={{ position: "absolute", left: 9, top: 9, color: "#68778b" }} />
          <input
            data-testid="search-project-files"
            className="search-input"
            value={filter}
            onChange={(event) => setFilter(event.target.value)}
            placeholder="Find a file…"
            style={{ padding: "7px 8px 7px 27px", fontSize: 10 }}
          />
        </div>
      </div>
      <div className="tree" role="tree" aria-label="Project files">
        {visible.map((file) => {
          const depth = file.path.split("/").length - 1;
          const isFolder = file.kind === "folder";
          const Icon = isFolder
            ? Folder
            : file.path.endsWith(".json")
              ? FileJson
              : file.path.endsWith(".py")
                ? FileCode2
                : FileIcon;
          const hasChildren = project.files.some((item) => item.path.startsWith(`${file.path}/`));
          return (
            <div
              key={file.id}
              className={`tree-row ${file.id === activeId ? "selected" : ""}`}
              style={{ paddingLeft: 7 + depth * 14 }}
              role="treeitem"
              aria-selected={file.id === activeId}
              data-testid={`tree-file-${file.id}`}
              onClick={() =>
                isFolder
                  ? setFolded((old) => {
                      const next = new Set(old);
                      next.has(file.path) ? next.delete(file.path) : next.add(file.path);
                      return next;
                    })
                  : onSelect(file)
              }
            >
              {isFolder && hasChildren ? (
                folded.has(file.path) ? <ChevronRight size={13} /> : <ChevronDown size={13} />
              ) : (
                <span style={{ width: 13 }} />
              )}
              <Icon
                size={14}
                color={isFolder ? "#8e9bb0" : file.path.endsWith(".py") ? "#72b9ff" : "#79879b"}
              />
              <span className="filename">{safeName(file.path)}</span>
              <span className="tree-actions" onClick={(event) => event.stopPropagation()}>
                <button
                  className="tree-action"
                  title="Rename"
                  data-testid={`rename-file-${file.id}`}
                  onClick={() => onRename(file)}
                >
                  <MoreHorizontal size={13} />
                </button>
                <button
                  className="tree-action"
                  title="Delete"
                  data-testid={`delete-file-${file.id}`}
                  onClick={() => onDelete(file)}
                >
                  <Trash2 size={12} />
                </button>
              </span>
            </div>
          );
        })}
        {!visible.length && <div className="muted-copy" style={{ padding: 12 }}>No files match that search.</div>}
      </div>
      <div style={{ padding: "8px 10px", borderTop: "1px solid #171e2a", display: "flex", gap: 6 }}>
        <button className="secondary-btn" style={{ flex: 1, justifyContent: "center" }} data-testid="import-zip" onClick={onImport}>
          <Upload size={13} /> Import ZIP
        </button>
        <button className="secondary-btn" style={{ flex: 1, justifyContent: "center" }} data-testid="import-py" onClick={onImportPy}>
          <FileCode2 size={13} /> Import .py
        </button>
        <button className="secondary-btn" style={{ flex: 1, justifyContent: "center" }} data-testid="export-zip" onClick={onExport}>
          <Download size={13} /> Export ZIP
        </button>
      </div>
    </aside>
  );
}
