import { type CSSProperties, type ReactNode, useCallback, useEffect, useMemo, useRef, useState } from "react";
import CodeMirror, { type ReactCodeMirrorRef } from "@uiw/react-codemirror";
import { python } from "@codemirror/lang-python";
import { indentUnit } from "@codemirror/language";
import { oneDark } from "@codemirror/theme-one-dark";
import { search, searchKeymap, openSearchPanel } from "@codemirror/search";
import { defaultKeymap, history, historyKeymap, indentWithTab, undo } from "@codemirror/commands";
import { EditorView, keymap } from "@codemirror/view";
import {
  Activity, AlertCircle, ArrowDownToLine, Braces, Check, ChevronDown, ChevronRight, Circle,
  Clipboard, Clock3, Code2, Command, Copy, Download, ExternalLink, Eye, File as FileIcon, FileCode2,
  FileJson, FilePlus2, FileText, Folder, FolderPlus, FolderTree, Image as ImageIcon, Info, LoaderCircle, MoreHorizontal,
  Package, PanelLeftClose, PanelLeftOpen, Play, Plus, RefreshCw, Search as SearchIcon,
  Settings2, Square, Terminal, Trash2, Upload, X, Zap,
} from "lucide-react";
import {
  addProjectFile, clearAllProjects, deleteProject, duplicateProject, duplicateProjectFile,
  exportProjectZip, exportProjectsBackup, getProject, importProjectZip, importProjectsBackup,
  listProjects, makeProject, normalizeProjectPath, PROJECT_TEMPLATES, removeProjectFile,
  renameProjectFile, saveProject, saveProjects, type Project, type ProjectFile, type ProjectTemplate,
} from "@/lib/project-store";
import { PythonRuntime, type RuntimeMessage } from "@/lib/python-runtime";
import {
  clearPreferences, clearRunHistory, DEFAULT_PREFERENCES, estimateBrowserStorage,
  exportPreferencesJson, formatBytes, listRunHistory, loadPreferences, parsePreferencesJson,
  savePreferences, saveRunHistory, type IDEPreferences, type RunHistoryEntry,
} from "@/lib/preferences-store";
import { SettingsPanel } from "@/components/SettingsPanel";
import { ProjectCreationForm } from "@/components/ProjectCreationForm";
import { HomeDashboard } from "@/components/HomeDashboard";
import {
  SiC, SiCplusplus, SiCss, SiDocker, SiGo, SiGnubash, SiHtml5, SiJavascript,
  SiDart, SiJson, SiKotlin, SiLua, SiMarkdown, SiOpenjdk, SiPerl, SiPhp, SiPython,
  SiR, SiRuby, SiRust, SiScala, SiSharp, SiSwift, SiTypescript,
} from "react-icons/si";
import type { IconType } from "react-icons";
import { getFileType, getImageMimeType, isImagePath } from "@/lib/file-types";
import { getEditorLanguageExtension } from "@/lib/editor-languages";
import { buildWebPreviewDocument } from "@/lib/web-preview";
import "@/index.css";

type OutputEntry = { stream: "stdout" | "stderr" | "system"; text: string; id: number };
type ModalKind = "new-project" | "project-list" | "rename-project" | "delete-project" | "new-file" | "rename-file" | "delete-file" | "run-settings" | "packages" | "requirements" | "env" | "settings" | "json" | "import-name" | "runtime-info" | "restore-backup" | "clear-storage" | null;
type ModalState = { kind: ModalKind; file?: ProjectFile; folderPath?: string } | null;
const ICON = 14;

function IconButton({ title, testId, onClick, children, className = "", disabled = false }: { title: string; testId: string; onClick: () => void; children: ReactNode; className?: string; disabled?: boolean }) {
  return <button type="button" title={title} aria-label={title} data-testid={testId} className={`icon-btn ${className}`} onClick={onClick} disabled={disabled}>{children}</button>;
}

function Modal({ title, onClose, children, footer }: { title: string; onClose: () => void; children: ReactNode; footer?: ReactNode }) {
  return <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
    <section className="modal" role="dialog" aria-modal="true" aria-label={title}>
      <header className="modal-head"><h2>{title}</h2><IconButton title="Close dialog" testId="close-dialog" onClick={onClose}><X size={16} /></IconButton></header>
      <div className="modal-content">{children}</div>
      {footer && <footer className="modal-foot">{footer}</footer>}
    </section>
  </div>;
}

function safeName(path: string) { return path.split("/").pop() || path; }

function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error(`Could not read ${file.name}.`));
    reader.onload = () => typeof reader.result === "string" ? resolve(reader.result) : reject(new Error(`Could not read ${file.name}.`));
    reader.readAsDataURL(file);
  });
}

const languageIcons: Record<string, IconType> = {
  python: SiPython,
  html: SiHtml5,
  css: SiCss,
  javascript: SiJavascript,
  typescript: SiTypescript,
  cpp: SiCplusplus,
  c: SiC,
  csharp: SiSharp,
  java: SiOpenjdk,
  go: SiGo,
  rust: SiRust,
  ruby: SiRuby,
  php: SiPhp,
  swift: SiSwift,
  kotlin: SiKotlin,
  shell: SiGnubash,
  lua: SiLua,
  perl: SiPerl,
  r: SiR,
  dart: SiDart,
  scala: SiScala,
  docker: SiDocker,
  json: SiJson,
  markdown: SiMarkdown,
};

function FileTypeIcon({ path, size = 14 }: { path: string; size?: number }) {
  const fileType = getFileType(path);
  const Logo = languageIcons[fileType.icon];
  if (Logo) return <Logo size={size} color={fileType.color} aria-hidden="true" />;
  const Icon = fileType.icon === "image" ? ImageIcon : fileType.icon === "document" ? FileText : fileType.category === "text" ? FileIcon : FileCode2;
  return <Icon size={size} color={fileType.color} aria-hidden="true" />;
}

function checkedProjectName(raw: string, projects: Project[], exceptId?: string): string | null {
  const name = raw.trim();
  if (!name) return null;
  if (name.length > 80 || /[\\/\u0000-\u001f]/.test(name)) return null;
  if (projects.some(item => item.id !== exceptId && item.name.trim().toLocaleLowerCase() === name.toLocaleLowerCase())) return null;
  return name;
}

function parseRunArguments(source: string): { args: string[]; error?: string } {
  const args: string[] = [];
  let value = "";
  let quote: "'" | "\"" | "" = "";
  let escaped = false;
  let started = false;
  for (const character of source.trim()) {
    if (escaped) {
      value += character;
      escaped = false;
      started = true;
    } else if (character === "\\" && quote !== "'") {
      escaped = true;
      started = true;
    } else if (quote) {
      if (character === quote) quote = "";
      else value += character;
      started = true;
    } else if (character === "'" || character === "\"") {
      quote = character;
      started = true;
    } else if (/\s/.test(character)) {
      if (started) args.push(value);
      value = "";
      started = false;
    } else {
      value += character;
      started = true;
    }
  }
  if (escaped) value += "\\";
  if (quote) return { args: [], error: "Close the quote in your script arguments." };
  if (started) args.push(value);
  return { args };
}

function Explorer({ project, collapsed, activeId, showHiddenFiles, onSelect, onToggle, onCreate, onRename, onDelete, onDuplicate, onImport, onImportFiles, onExport }: {
  project: Project; collapsed: boolean; activeId: string; onSelect: (file: ProjectFile) => void; onToggle: () => void;
  showHiddenFiles: boolean;
  onCreate: (kind: "file" | "folder", folderPath?: string) => void; onRename: (file: ProjectFile) => void;
  onDelete: (file: ProjectFile) => void; onDuplicate: (file: ProjectFile) => void; onImport: () => void; onImportFiles: () => void; onExport: () => void;
}) {
  const [folded, setFolded] = useState<Set<string>>(new Set());
  const [filter, setFilter] = useState("");
  const visible = useMemo(() => {
    const match = filter.trim().toLowerCase();
    return project.files.filter(file => (showHiddenFiles || !file.path.split("/").some(part => part.startsWith("."))) && (!match || file.path.toLowerCase().includes(match))).sort((a, b) => {
      const aa = a.path.split("/"); const bb = b.path.split("/");
      if (aa.length !== bb.length) return aa.length - bb.length;
      return a.kind === b.kind ? aa.at(-1)!.localeCompare(bb.at(-1)!) : a.kind === "folder" ? -1 : 1;
    }).filter(file => {
      const ancestors = file.path.split("/").slice(0, -1);
      let parent = "";
      for (const part of ancestors) { parent = parent ? `${parent}/${part}` : part; if (folded.has(parent) && !match) return false; }
      return true;
    });
  }, [project.files, folded, filter, showHiddenFiles]);
  return <aside className={`explorer ${collapsed ? "collapsed" : ""}`} data-testid="project-explorer">
    <div className="panel-head"><span>EXPLORER</span><div className="file-tools">
      <IconButton title="New file" testId="new-file" onClick={() => onCreate("file")}><FilePlus2 size={ICON} /></IconButton>
      <IconButton title="New folder" testId="new-folder" onClick={() => onCreate("folder")}><FolderPlus size={ICON} /></IconButton>
      <IconButton title="Import or export project" testId="project-files-menu" onClick={onExport}><MoreHorizontal size={ICON} /></IconButton>
      <IconButton title="Collapse explorer" testId="collapse-explorer" onClick={onToggle}><PanelLeftClose size={ICON} /></IconButton>
    </div></div>
    <div className="explorer-project"><FolderTree size={14} color="#168bff" /><span>{project.name.toUpperCase()}</span></div>
    <div style={{ padding: "2px 10px 8px", display: "flex", gap: 6 }}>
      <div style={{ position: "relative", flex: 1 }}><SearchIcon size={12} style={{ position: "absolute", left: 9, top: 9, color: "#68778b" }} /><input data-testid="search-project-files" className="search-input" value={filter} onChange={e => setFilter(e.target.value)} placeholder="Find a file…" style={{ padding: "7px 8px 7px 27px", fontSize: 10 }} /></div>
    </div>
    <div className="tree" role="tree" aria-label="Project files">
      {visible.map(file => {
        const depth = file.path.split("/").length - 1;
        const isFolder = file.kind === "folder";
        const hasChildren = project.files.some(item => item.path.startsWith(`${file.path}/`));
        return <div key={file.id} className={`tree-row ${file.id === activeId ? "selected" : ""}`} style={{ paddingLeft: 7 + depth * 14 }} role="treeitem" aria-selected={file.id === activeId} data-testid={`tree-file-${file.id}`} onClick={() => isFolder ? setFolded(old => { const next = new Set(old); next.has(file.path) ? next.delete(file.path) : next.add(file.path); return next; }) : onSelect(file)}>
          {isFolder && hasChildren ? (folded.has(file.path) ? <ChevronRight size={13} /> : <ChevronDown size={13} />) : <span style={{ width: 13 }} />}
          {isFolder ? <Folder size={14} color="#8e9bb0" /> : <FileTypeIcon path={file.path} size={14} />}
          <span className="filename">{safeName(file.path)}</span>
          <span className="tree-actions" onClick={e => e.stopPropagation()}>
            <button className="tree-action" title="Rename" data-testid={`rename-file-${file.id}`} onClick={() => onRename(file)}><MoreHorizontal size={13} /></button>
             {!isFolder && <button className="tree-action" title="Duplicate file" data-testid={`duplicate-file-${file.id}`} onClick={() => onDuplicate(file)}><Copy size={12} /></button>}
            <button className="tree-action" title="Delete" data-testid={`delete-file-${file.id}`} onClick={() => onDelete(file)}><Trash2 size={12} /></button>
          </span>
        </div>;
      })}
      {!visible.length && <div className="muted-copy" style={{ padding: 12 }}>No files match that search.</div>}
    </div>
    <div style={{ padding: "8px 10px", borderTop: "1px solid #171e2a", display: "flex", gap: 6 }}>
      <button className="secondary-btn" style={{ flex: 1, justifyContent: "center" }} data-testid="import-zip" onClick={onImport}><Upload size={13} /> Import ZIP</button>
      <button className="secondary-btn" style={{ flex: 1, justifyContent: "center" }} data-testid="import-source-files" onClick={onImportFiles}><FileCode2 size={13} /> Import files</button>
      <button className="secondary-btn" style={{ flex: 1, justifyContent: "center" }} data-testid="export-zip" onClick={onExport}><Download size={13} /> Export ZIP</button>
    </div>
  </aside>;
}

function App() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [project, setProject] = useState<Project | null>(null);
  const [booting, setBooting] = useState(true);
  const [collapsed, setCollapsed] = useState(() => window.matchMedia("(max-width: 800px)").matches);
  const [mobileExplorer, setMobileExplorer] = useState(false);
  const [modal, setModal] = useState<ModalState>(null);
  const [toast, setToast] = useState("");
  const [outputs, setOutputs] = useState<OutputEntry[]>([]);
  const [panelOpen, setPanelOpen] = useState(true);
  const [panelTab, setPanelTab] = useState<"output" | "repl" | "history" | "preview">("output");
  const [runHistory, setRunHistory] = useState<RunHistoryEntry[]>([]);
  const [runtimeStatus, setRuntimeStatus] = useState<"starting" | "ready" | "error" | "running">("starting");
  const [runtimeVersion, setRuntimeVersion] = useState("Pyodide loading");
  const [runTime, setRunTime] = useState<number | null>(null);
  const [lastResult, setLastResult] = useState<"idle" | "success" | "error">("idle");
  const [argsText, setArgsText] = useState("");
  const [timeoutSeconds, setTimeoutSeconds] = useState(DEFAULT_PREFERENCES.timeoutSeconds);
  const [preferences, setPreferences] = useState<IDEPreferences>(DEFAULT_PREFERENCES);
  const [replText, setReplText] = useState("");
  const [packageQuery, setPackageQuery] = useState("");
  const [packageResults, setPackageResults] = useState<Array<{ name: string; version: string; summary: string }>>([]);
  const [packageBusy, setPackageBusy] = useState(false);
  const [packageProgress, setPackageProgress] = useState("");
  const [reqText, setReqText] = useState("");
  const [envDraft, setEnvDraft] = useState("");
  const [formValue, setFormValue] = useState("");
  const [projectSearch, setProjectSearch] = useState("");
  const [pendingImport, setPendingImport] = useState<File | null>(null);
  const [pendingBackupImport, setPendingBackupImport] = useState<File | null>(null);
  const [projectTemplate, setProjectTemplate] = useState<ProjectTemplate>("empty");
  const [initialFileName, setInitialFileName] = useState("main.py");
  const [projectDescription, setProjectDescription] = useState("");
  const [projectColor, setProjectColor] = useState(DEFAULT_PREFERENCES.defaultProjectColor);
  const [includeReadme, setIncludeReadme] = useState(false);
  const [mobileView, setMobileView] = useState<"editor" | "files" | "output" | "preview">("output");
  const editorRef = useRef<ReactCodeMirrorRef>(null);
  const runtimeRef = useRef<PythonRuntime | null>(null);
  const runtimeFilesSnapshot = useRef("");
  const importRef = useRef<HTMLInputElement>(null);
  const sourceRef = useRef<HTMLInputElement>(null);
  const requirementsRef = useRef<HTMLInputElement>(null);
  const outputRef = useRef<HTMLDivElement>(null);
  const timerRef = useRef<number | undefined>(undefined);
  const executionTimeoutRef = useRef<number | undefined>(undefined);
  const runtimeGeneration = useRef(0);
  const activeRunRef = useRef<{
    projectId: string;
    projectName: string;
    filePath: string;
    startedAt: number;
    output: Array<{ stream: OutputEntry["stream"]; text: string }>;
  } | null>(null);
  const preferencesRef = useRef<IDEPreferences>(DEFAULT_PREFERENCES);
  const [storageEstimate, setStorageEstimate] = useState<{ usage?: number; quota?: number } | null>(null);
  const [dirty, setDirty] = useState(false);
  const [editorText, setEditorText] = useState("");

  const activeFile = project?.files.find(file => file.id === project.activeFileId) ?? null;
  const activeFileType = activeFile ? getFileType(activeFile.path) : null;
  const canPreviewActiveFile = Boolean(activeFileType?.previewable);
  const previewDocument = useMemo(() => {
    if (!project || !activeFile || !canPreviewActiveFile) return null;
    const files = project.files.map(file => file.id === activeFile.id ? { ...file, content: editorText } : file);
    return buildWebPreviewDocument(files, activeFile.path);
  }, [project, activeFile?.id, activeFile?.path, editorText, canPreviewActiveFile]);
  const visibleProjects = projects.filter(item => item.name.toLowerCase().includes(projectSearch.toLowerCase()));
  const notify = useCallback((message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(current => current === message ? "" : current), 2800);
  }, []);
  const triggerHaptic = () => {
    if (preferences.hapticFeedback && "vibrate" in navigator) navigator.vibrate?.(8);
  };
  const updatePreferences = useCallback((changes: Partial<IDEPreferences>) => {
    const next = { ...preferencesRef.current, ...changes };
    preferencesRef.current = next;
    setPreferences(next);
    if (typeof changes.timeoutSeconds === "number") setTimeoutSeconds(changes.timeoutSeconds);
    if (changes.preserveRunHistory === false) {
      setRunHistory([]);
      void clearRunHistory().catch(error => notify(error instanceof Error ? error.message : "Could not clear run history."));
    }
    void savePreferences(next).catch(error => notify(error instanceof Error ? error.message : "Could not save settings."));
  }, [notify]);
  const resetPreferences = useCallback(async () => {
    preferencesRef.current = DEFAULT_PREFERENCES;
    setPreferences(DEFAULT_PREFERENCES);
    setTimeoutSeconds(DEFAULT_PREFERENCES.timeoutSeconds);
    try {
      await clearPreferences();
      notify("Settings restored to defaults");
    } catch (error) {
      notify(error instanceof Error ? error.message : "Could not reset settings.");
    }
  }, [notify]);
  const addOutput = useCallback((text: string, stream: OutputEntry["stream"] = "system") => {
    const outputLimit = 12_000;
    const boundedText = text.length > outputLimit ? `${text.slice(0, outputLimit)}\n[Output truncated]` : text;
    activeRunRef.current?.output.push({ text: boundedText, stream });
    setOutputs(current => [...current, { text: boundedText, stream, id: Date.now() + Math.random() }].slice(-1000));
  }, []);
  const finalizeRun = useCallback(async (
    status: RunHistoryEntry["status"],
    durationMs?: number,
    exitCode?: number,
  ) => {
    const active = activeRunRef.current;
    activeRunRef.current = null;
    if (!active || !preferencesRef.current.preserveRunHistory) return;
    const entry: RunHistoryEntry = {
      id: crypto.randomUUID(),
      projectId: active.projectId,
      projectName: active.projectName,
      filePath: active.filePath,
      status,
      output: active.output.slice(-300).map(item => ({ ...item, text: item.text.slice(0, 12_000) })),
      durationMs: durationMs ?? Math.max(0, Date.now() - active.startedAt),
      exitCode,
      createdAt: Date.now(),
    };
    try {
      await saveRunHistory(entry);
      setRunHistory(items => [entry, ...items].slice(0, 50));
    } catch (error) {
      notify(error instanceof Error ? error.message : "Could not save run history.");
    }
  }, [notify]);
  const startRuntime = useCallback((target: Project) => {
    const generation = ++runtimeGeneration.current;
    runtimeRef.current?.dispose();
    setRuntimeStatus("starting"); setRuntimeVersion("Browser Python loading"); setLastResult("idle");
    const files = target.files.filter(item => item.kind === "file").map(({ path, content }) => ({ path, content }));
    runtimeFilesSnapshot.current = JSON.stringify(files);
    const runtime = new PythonRuntime(target.id, files, target.installedPackages, (message: RuntimeMessage) => {
      if (generation !== runtimeGeneration.current) return;
      if (message.type === "ready") { setRuntimeVersion(`Python ${message.pythonVersion}`); setRuntimeStatus("ready"); addOutput(`Python ${message.pythonVersion} · isolated browser runtime ready`); if (message.failedPackages?.length) addOutput(`Could not restore: ${message.failedPackages.join(", ")}`, "stderr"); }
      if (message.type === "output") addOutput(message.text, message.stream);
      if (message.type === "fatal") { setRuntimeStatus("error"); addOutput(`Runtime error: ${message.error}`, "stderr"); }
      if (message.type === "progress") { setPackageProgress(message.text); addOutput(message.text); }
    });
    runtimeRef.current = runtime;
    runtime.ready().catch(error => {
      if (generation === runtimeGeneration.current) { setRuntimeStatus("error"); setRuntimeVersion("Runtime unavailable"); addOutput(`Could not start browser Python: ${error instanceof Error ? error.message : String(error)}`, "stderr"); }
    });
  }, [addOutput]);

  const reloadProjects = useCallback(async (selectId?: string) => {
    const all = await listProjects();
    setProjects(all);
    if (selectId) {
      const chosen = await getProject(selectId);
      if (chosen) setProject(chosen);
    }
  }, []);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [all, savedPreferences, storedRuns] = await Promise.all([listProjects(), loadPreferences(), listRunHistory()]);
        if (!cancelled) {
          preferencesRef.current = savedPreferences;
          setPreferences(savedPreferences);
          setRunHistory(savedPreferences.preserveRunHistory ? storedRuns : []);
          setTimeoutSeconds(savedPreferences.timeoutSeconds);
          setMobileView(savedPreferences.openRunResultsFullScreen ? "output" : "editor");
          setProjects(all);
          const currentId = localStorage.getItem("vortex-current-project");
          const selected = savedPreferences.restoreLastProject
            ? all.find(item => item.id === currentId) ?? all[0]
            : undefined;
          if (selected) {
            const latest = await getProject(selected.id);
            if (latest) {
              const restored = savedPreferences.restoreOpenTabs
                ? latest
                : { ...latest, openFileIds: latest.activeFileId ? [latest.activeFileId] : [] };
              setProject(restored);
            }
          }
        }
      } catch (error) {
        if (!cancelled) notify(error instanceof Error ? error.message : "Local project storage is unavailable.");
      } finally { if (!cancelled) setBooting(false); }
    })();
    return () => { cancelled = true; };
  }, [notify]);

  useEffect(() => {
    void estimateBrowserStorage().then(setStorageEstimate).catch(() => setStorageEstimate(null));
  }, [projects.length]);

  useEffect(() => {
    if (preferences.autoScrollOutput && panelTab === "output" && outputRef.current) {
      outputRef.current.scrollTop = outputRef.current.scrollHeight;
    }
  }, [outputs, preferences.autoScrollOutput, panelTab]);

  useEffect(() => {
    const root = document.documentElement;
    root.dataset.vortexTheme = preferences.theme;
    root.dataset.reducedMotion = String(preferences.reducedMotion || preferences.lowPowerMode);
    root.dataset.lowPower = String(preferences.lowPowerMode);
    root.dataset.highContrast = String(preferences.highContrast);
    root.style.setProperty("--violet", preferences.theme === "cyberpunk" ? preferences.secondaryAccentColor : preferences.accentColor);
    root.style.setProperty("--cyan", preferences.theme === "cyberpunk" ? preferences.accentColor : preferences.secondaryAccentColor);
    root.style.setProperty("--user-accent", preferences.accentColor);
    root.style.setProperty("--interface-font-size", `${preferences.interfaceFontSize}px`);
    root.style.setProperty("--editor-font-family", preferences.editorFontFamily === "IBM Plex Mono" ? "'IBM Plex Mono', monospace" : preferences.editorFontFamily);
    root.style.setProperty("--editor-line-height", String(preferences.editorLineHeight));
    root.dataset.density = preferences.density;
    root.dataset.indentationGuides = String(preferences.indentationGuides);
  }, [preferences]);

  useEffect(() => {
    const media = window.matchMedia("(max-width: 800px)");
    const updateForViewport = (event: MediaQueryListEvent) => setCollapsed(event.matches);
    media.addEventListener("change", updateForViewport);
    return () => media.removeEventListener("change", updateForViewport);
  }, []);

  useEffect(() => {
    if (!project) return;
    localStorage.setItem("vortex-current-project", project.id);
    const source = project.files.find(item => item.id === project.activeFileId)?.content ?? "";
    setEditorText(source); setDirty(false);
    startRuntime(project);
    return () => { window.clearTimeout(executionTimeoutRef.current); runtimeRef.current?.dispose(); runtimeRef.current = null; };
  }, [project?.id, startRuntime]); // Runtime is isolated per project, intentionally not restarted for edits.

  useEffect(() => {
    if (!project || !activeFile || !dirty || !preferences.autoSave) return;
    window.clearTimeout(timerRef.current);
    timerRef.current = window.setTimeout(() => persistEditor(false), preferences.autoSaveDelayMs);
    return () => window.clearTimeout(timerRef.current);
  }, [editorText, dirty, project?.id, activeFile?.id, preferences.autoSave, preferences.autoSaveDelayMs]);

  useEffect(() => {
    if (panelTab === "preview" && !canPreviewActiveFile) setPanelTab("output");
  }, [panelTab, canPreviewActiveFile]);

  useEffect(() => {
    const handleKeys = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "s") { event.preventDefault(); persistEditor(true); }
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "enter") { event.preventDefault(); void runProgram(); }
      if (event.key === "Escape" && modal) setModal(null);
    };
    window.addEventListener("keydown", handleKeys);
    return () => window.removeEventListener("keydown", handleKeys);
  });

  const persistEditor = useCallback(async (showNotice = false) => {
    if (!project || !activeFile) return;
    const updated: Project = {
      ...project, files: project.files.map(file => file.id === activeFile.id ? { ...file, content: editorText, updatedAt: Date.now() } : file),
      updatedAt: Date.now(),
    };
    setProject(updated); setDirty(false);
    try { await saveProject(updated); setProjects(items => items.map(item => item.id === updated.id ? updated : item)); if (showNotice) notify("Saved to this browser"); }
    catch (error) { notify(error instanceof Error ? error.message : "Could not save locally."); }
  }, [project, activeFile, editorText, notify]);

  const updateProject = useCallback(async (next: Project) => {
    const current = dirty && activeFile && project?.id === next.id
      ? { ...next, files: next.files.map(file => file.id === activeFile.id ? { ...file, content: editorText, updatedAt: Date.now() } : file) }
      : next;
    const selectedFileChanged = project?.id === current.id && project.activeFileId !== current.activeFileId;
    setProject(current); setProjects(items => items.map(item => item.id === current.id ? current : item));
    if (dirty && activeFile && project?.id === next.id) setDirty(false);
    if (selectedFileChanged) {
      const selectedFile = current.files.find(file => file.id === current.activeFileId);
      setEditorText(selectedFile?.content ?? "");
      setDirty(false);
    }
    try { await saveProject(current); } catch (error) { notify(error instanceof Error ? error.message : "Could not save project."); }
  }, [notify, dirty, activeFile, project, editorText]);

  const runProgram = useCallback(async () => {
    if (!project || !activeFile || packageBusy) return;
    const fileType = getFileType(activeFile.path);
    if (fileType.previewable) {
      setPanelTab("preview");
      setPanelOpen(true);
      setMobileExplorer(false);
      setMobileView("preview");
      return;
    }
    if (fileType.language !== "python") {
      notify(`${fileType.label} files can be edited here, but this workspace has no ${fileType.label} execution runtime.`);
      return;
    }
    if (runtimeStatus === "running") return;
    if (dirty) await persistEditor(false);
    const parsedArgs = parseRunArguments(argsText);
    if (parsedArgs.error) {
      notify(parsedArgs.error);
      return;
    }
    if (preferences.autoClearOutput) setOutputs([]);
    if (preferences.openRunResultsFullScreen) setMobileView("output");
    const synchronizedFiles = project.files.filter(item => item.kind === "file").map(file => ({
      path: file.path,
      content: file.id === activeFile.id ? editorText : file.content,
    }));
    let runtime = runtimeRef.current;
    if (!runtime || runtimeStatus === "error" || JSON.stringify(synchronizedFiles) !== runtimeFilesSnapshot.current) {
      const synchronizedProject = {
        ...project,
        files: project.files.map(file => file.id === activeFile.id ? { ...file, content: editorText, updatedAt: Date.now() } : file),
      };
      startRuntime(synchronizedProject);
      runtime = runtimeRef.current;
      if (!runtime) return;
      addOutput("Refreshing project files in isolated browser Python…");
      try { await runtime.ready(); } catch (error) { notify(error instanceof Error ? error.message : "The browser runtime could not restart."); return; }
    }
    if (!runtime) return;
    setPanelOpen(true); setPanelTab("output"); setRuntimeStatus("running"); setLastResult("idle"); setRunTime(null);
    activeRunRef.current = {
      projectId: project.id,
      projectName: project.name,
      filePath: activeFile.path,
      startedAt: Date.now(),
      output: [],
    };
    addOutput(`▶ ${activeFile.path}`, "system");
    window.clearTimeout(executionTimeoutRef.current);
    executionTimeoutRef.current = window.setTimeout(() => {
      if (runtimeRef.current !== runtime) return;
      runtime.stop();
      runtimeRef.current = null;
      addOutput(`Execution exceeded ${timeoutSeconds} seconds. The sandbox was terminated.`, "stderr");
      setLastResult("error");
      void finalizeRun("error");
      const latestProject = {
        ...project,
        files: project.files.map(file => file.id === activeFile.id ? { ...file, content: editorText } : file),
      };
      startRuntime(latestProject);
    }, timeoutSeconds * 1000);
    try {
      const result = await runtime.request({ type: "run", code: editorText, fileName: activeFile.path, args: parsedArgs.args, envVars: project.envVars });
      window.clearTimeout(executionTimeoutRef.current);
      if (result.type === "result") {
        if (result.error === "Execution stopped.") return;
        setRunTime(result.durationMs ?? null); setLastResult(result.ok ? "success" : "error"); setRuntimeStatus("ready");
        addOutput(`${result.ok ? "Process finished" : "Process exited with errors"} · exit ${result.exitCode ?? (result.ok ? 0 : 1)}${preferences.showExecutionTime ? ` · ${result.durationMs ?? 0} ms` : ""}`);
        await finalizeRun(result.ok ? "success" : "error", result.durationMs, result.exitCode);
      }
    } catch (error) {
      setRuntimeStatus("error");
      addOutput(error instanceof Error ? error.message : "Execution failed.", "stderr");
      await finalizeRun("error");
    }
  }, [project, activeFile, runtimeStatus, packageBusy, dirty, persistEditor, editorText, argsText, preferences, timeoutSeconds, addOutput, notify, startRuntime, finalizeRun]);

  const stopProgram = () => {
    window.clearTimeout(executionTimeoutRef.current);
    runtimeRef.current?.stop(); runtimeRef.current = null;
    addOutput("Execution stopped. Starting a fresh isolated browser runtime; Python state has been cleared.");
    void finalizeRun("stopped");
    if (project) startRuntime(project);
  };
  const clearOutput = () => setOutputs([]);
  const copyOutput = async () => {
    try {
      await navigator.clipboard.writeText(outputs.map(item => item.text).join("\n"));
      notify("Output copied");
    } catch {
      notify("Clipboard access is unavailable in this browser.");
    }
  };
  const viewHistoryEntry = async (entry: RunHistoryEntry) => {
    if (entry.projectId !== project?.id) {
      const source = await getProject(entry.projectId);
      if (source) await switchProject(source);
    }
    setOutputs(entry.output.map((item, index) => ({ ...item, id: Date.now() + index })));
    setPanelTab("output");
    setPanelOpen(true);
    setMobileView("output");
  };
  const clearSavedHistory = async () => {
    if (!window.confirm("Clear the saved run history from this browser?")) return;
    try {
      await clearRunHistory();
      setRunHistory([]);
      notify("Run history cleared");
    } catch (error) {
      notify(error instanceof Error ? error.message : "Could not clear run history.");
    }
  };
  const selectFile = async (file: ProjectFile) => {
    if (!project) return;
    const base = dirty && activeFile ? { ...project, files: project.files.map(item => item.id === activeFile.id ? { ...item, content: editorText, updatedAt: Date.now() } : item) } : project;
    const next = { ...base, activeFileId: file.id, openFileIds: [...new Set([...base.openFileIds, file.id])], lastOpenedAt: Date.now() };
    if (dirty) { await saveProject(next); setDirty(false); }
    setProject(next); void saveProject(next); setMobileExplorer(false); setMobileView("editor");
  };
  const closeTab = (id: string) => {
    if (!project) return;
    if (id === activeFile?.id && dirty && preferences.confirmCloseUnsaved && !window.confirm("Save your unsaved changes before closing this file?")) return;
    const base = dirty && activeFile ? { ...project, files: project.files.map(item => item.id === activeFile.id ? { ...item, content: editorText, updatedAt: Date.now() } : item) } : project;
    const openFileIds = base.openFileIds.filter(fileId => fileId !== id);
    const activeFileId = base.activeFileId === id ? (openFileIds.at(-1) ?? base.files.find(f => f.kind === "file")?.id ?? "") : base.activeFileId;
    const next = { ...base, openFileIds, activeFileId };
    if (dirty) setDirty(false);
    setProject(next); void saveProject(next);
  };
  const createProject = async () => {
    const name = checkedProjectName(formValue, projects);
    if (!name) {
      notify("Use a unique project name (1–80 characters, without slashes or control characters).");
      return;
    }
    try {
      const created = makeProject(name, {
        template: projectTemplate,
        initialFileName,
        description: projectDescription,
        color: projectColor,
        includeReadme,
      });
      await saveProject(created);
      setProjects(items => [created, ...items]);
      setProject(created);
      setMobileView(preferences.openRunResultsFullScreen ? "output" : "editor");
      if (preferences.openRunResultsFullScreen) { setPanelTab("output"); setPanelOpen(true); }
      setModal(null);
      setFormValue("");
      setProjectDescription("");
      setOutputs([]);
      notify("Project created");
    } catch (error) {
      notify(error instanceof Error ? error.message : "Could not create the project.");
    }
  };
  const renameProject = async () => {
    if (!project || !formValue.trim()) return;
    const name = checkedProjectName(formValue, projects, project.id);
    if (!name) {
      notify("Use a unique project name (1–80 characters, without slashes or control characters).");
      return;
    }
    await updateProject({ ...project, name, updatedAt: Date.now() }); setModal(null); notify("Project renamed");
  };
  const removeProject = async () => {
    if (!project) return;
    const next = projects.find(item => item.id !== project.id) ?? null;
    try {
      runtimeRef.current?.dispose();
      await deleteProject(project.id);
      setProjects(items => items.filter(item => item.id !== project.id));
      setProject(next);
      if (!next) setFormValue("");
      setModal(null);
      setOutputs([]);
      notify("Project deleted");
    } catch (error) {
      notify(error instanceof Error ? error.message : "Could not delete this project.");
    }
  };
  const createFile = async (kind: "file" | "folder", path = formValue) => {
    if (!project) return;
    try {
      const requestedPath = kind === "file" && !safeName(path).includes(".") ? `${path}.py` : path;
      const next = addProjectFile(project, requestedPath, kind);
      await updateProject(next); setModal(null); setFormValue(""); notify(kind === "folder" ? "Folder created" : "File created");
    } catch (error) { notify(error instanceof Error ? error.message : "Could not create that path."); }
  };
  const renameFile = async () => {
    if (!project || !modal?.file) return;
    try { await updateProject(renameProjectFile(project, modal.file.id, formValue)); setModal(null); setFormValue(""); notify("Path updated"); }
    catch (error) { notify(error instanceof Error ? error.message : "Could not rename that path."); }
  };
  const deleteFileItem = async (file: ProjectFile) => {
    if (!project) return;
    try {
      const base = dirty && activeFile
        ? { ...project, files: project.files.map(item => item.id === activeFile.id ? { ...item, content: editorText, updatedAt: Date.now() } : item) }
        : project;
      await updateProject(removeProjectFile(base, file.id));
      setModal(null);
      notify(`${safeName(file.path)} deleted`);
    } catch (error) {
      notify(error instanceof Error ? error.message : "Could not delete that path.");
    }
  };
  const removeFile = async () => {
    if (modal?.file) await deleteFileItem(modal.file);
  };
  const duplicateFile = async (file: ProjectFile) => {
    if (!project) return;
    try {
      const base = dirty && activeFile
        ? { ...project, files: project.files.map(item => item.id === activeFile.id ? { ...item, content: editorText, updatedAt: Date.now() } : item) }
        : project;
      await updateProject(duplicateProjectFile(base, file.id));
      setMobileView("editor");
      notify(`${safeName(file.path)} duplicated`);
    } catch (error) {
      notify(error instanceof Error ? error.message : "Could not duplicate that file.");
    }
  };
  const switchProject = async (target: Project) => {
    if (dirty) await persistEditor(false);
    const latest = await getProject(target.id);
    if (latest) {
      const touched = { ...latest, lastOpenedAt: Date.now() }; await saveProject(touched);
      setProject(touched); setProjects(items => [touched, ...items.filter(item => item.id !== touched.id)]);
      setOutputs([]); setRuntimeStatus("starting"); setMobileView(preferences.openRunResultsFullScreen ? "output" : "editor"); if (preferences.openRunResultsFullScreen) { setPanelTab("output"); setPanelOpen(true); } setModal(null);
    }
  };

  const openNewPath = (kind: "file" | "folder", folderPath?: string) => {
    void kind;
    setFormValue(folderPath ? `${folderPath}/` : "");
    setModal({ kind: "new-file", folderPath });
  };
  const saveAs = () => {
    setFormValue(activeFile ? activeFile.path.replace(/(\.[^.]+)?$/, "-copy$1") : "new_file.py");
    setModal({ kind: "new-file" });
  };
  const makeSaveAs = async () => {
    if (!project) return;
    try {
      const normalized = normalizeProjectPath(formValue);
      if (project.files.some(file => file.path === normalized)) { notify("That path already exists. Choose another name; overwriting is disabled."); return; }
      const added = addProjectFile(project, normalized, "file");
      const file = added.files.find(item => item.id === added.activeFileId)!;
      file.content = editorText; await updateProject(added); setDirty(false); setModal(null); setFormValue(""); notify("Copy saved as a new file");
    } catch (error) { notify(error instanceof Error ? error.message : "Could not save as."); }
  };
  const downloadSource = () => {
    if (!activeFile) return;
    const link = document.createElement("a"); link.href = URL.createObjectURL(new Blob([editorText], { type: "text/plain" })); link.download = safeName(activeFile.path); link.click(); URL.revokeObjectURL(link.href);
  };
  const downloadBlob = (blob: Blob, name: string) => {
    const link = document.createElement("a"); link.href = URL.createObjectURL(blob); link.download = name; link.click(); window.setTimeout(() => URL.revokeObjectURL(link.href), 1000);
  };
  const exportZip = async () => { if (!project) return; try { downloadBlob(await exportProjectZip(project), `${project.name.replace(/[^\w.-]+/g, "-")}.zip`); notify("Project ZIP exported"); } catch (error) { notify(error instanceof Error ? error.message : "ZIP export failed."); } };
  const exportAllProjects = async () => {
    try {
      downloadBlob(await exportProjectsBackup(projects), `vortex-backup-${new Date().toISOString().slice(0, 10)}.zip`);
      notify("Full project backup exported");
    } catch (error) {
      notify(error instanceof Error ? error.message : "Could not create project backup.");
    }
  };
  const beginBackupImport = (file: File) => {
    setPendingBackupImport(file);
    setModal({ kind: "restore-backup" });
  };
  const finishBackupImport = async () => {
    if (!pendingBackupImport) return;
    try {
      const imported = await importProjectsBackup(pendingBackupImport);
      await saveProjects(imported);
      setProjects(current => [...imported, ...current]);
      setPendingBackupImport(null);
      setModal(null);
      notify(`${imported.length} project${imported.length === 1 ? "" : "s"} restored without replacing existing projects`);
    } catch (error) {
      notify(error instanceof Error ? error.message : "Could not restore that backup.");
    }
  };
  const removeAllProjects = async () => {
    try {
      runtimeRef.current?.dispose();
      await clearAllProjects();
      setProjects([]);
      setProject(null);
      setOutputs([]);
      setDirty(false);
      localStorage.removeItem("vortex-current-project");
      setModal(null);
      setMobileView("output");
      notify("All local projects were deleted");
    } catch (error) {
      notify(error instanceof Error ? error.message : "Could not delete local projects.");
    }
  };
  const duplicateProjectItem = async (source: Project) => {
    try {
      const latest = source.id === project?.id && dirty && activeFile
        ? { ...source, files: source.files.map(file => file.id === activeFile.id ? { ...file, content: editorText, updatedAt: Date.now() } : file) }
        : await getProject(source.id) ?? source;
      let name = `${latest.name} copy`;
      let suffix = 2;
      while (projects.some(item => item.name.toLocaleLowerCase() === name.toLocaleLowerCase())) name = `${latest.name} copy ${suffix++}`;
      const copy = duplicateProject(latest, name);
      await saveProject(copy);
      setProjects(items => [copy, ...items]);
      setProject(copy);
      setDirty(false);
      setOutputs([]);
      setModal(null);
      setMobileView(preferences.openRunResultsFullScreen ? "output" : "editor");
      if (preferences.openRunResultsFullScreen) { setPanelTab("output"); setPanelOpen(true); }
      notify("Project duplicated");
    } catch (error) {
      notify(error instanceof Error ? error.message : "Could not duplicate this project.");
    }
  };
  const exportSettings = () => {
    downloadBlob(new Blob([exportPreferencesJson(preferences)], { type: "application/json" }), "vortex-preferences.json");
    notify("Preferences exported");
  };
  const importSettings = (text: string) => {
    try {
      const imported = parsePreferencesJson(text);
      preferencesRef.current = imported;
      setPreferences(imported);
      setTimeoutSeconds(imported.timeoutSeconds);
      void savePreferences(imported).then(() => notify("Preferences imported")).catch(error => notify(error instanceof Error ? error.message : "Could not save imported preferences."));
    } catch (error) {
      notify(error instanceof Error ? error.message : "Invalid preferences file.");
    }
  };
  const startImportZip = (file: File) => { setPendingImport(file); setFormValue(file.name.replace(/\.zip$/i, "")); setModal({ kind: "import-name" }); };
  const finishImportZip = async () => {
    if (!pendingImport) return;
    try {
      const imported = await importProjectZip(pendingImport, formValue); 
      // Imports always create a new project. Existing project names are allowed, paths never overwrite.
      await saveProject(imported); setProjects(items => [imported, ...items]); setProject(imported); setPendingImport(null); setModal(null); setOutputs([]); notify("ZIP imported as a new project");
    } catch (error) { notify(error instanceof Error ? error.message : "Could not import ZIP."); }
  };
  const importSourceFiles = async (sourceFiles: File[]) => {
    if (!project) return;
    try {
      let next = project;
      const occupied = new Set(project.files.map(item => item.path.toLocaleLowerCase()));
      for (const file of sourceFiles) {
        const originalPath = file.name.replace(/[\\/\u0000-\u001f]/g, "_").trim();
        if (!originalPath) continue;
        const dot = originalPath.lastIndexOf(".");
        const stem = dot > 0 ? originalPath.slice(0, dot) : originalPath;
        const extension = dot > 0 ? originalPath.slice(dot) : "";
        let path = originalPath;
        for (let suffix = 2; occupied.has(path.toLocaleLowerCase()); suffix += 1) path = `${stem}-${suffix}${extension}`;
        occupied.add(path.toLocaleLowerCase());

        let content: string;
        if (isImagePath(path)) {
          content = await readFileAsDataUrl(file);
          if (content.startsWith("data:;")) content = content.replace("data:;", `data:${getImageMimeType(path) ?? "application/octet-stream"};`);
        } else {
          content = await file.text();
        }
        const updated = addProjectFile(next, path, "file");
        next = {
          ...updated,
          files: updated.files.map(item => item.id === updated.activeFileId ? { ...item, content, updatedAt: Date.now() } : item),
        };
      }
      await updateProject(next);
      notify(`${sourceFiles.length} file${sourceFiles.length === 1 ? "" : "s"} imported`);
    } catch (error) { notify(error instanceof Error ? error.message : "Could not import files."); }
  };
  const createFromProjectButton = () => {
    setFormValue("");
    setProjectTemplate((preferences.defaultProjectTemplate as ProjectTemplate) || "empty");
    setInitialFileName(preferences.defaultInitialFilename);
    setProjectDescription("");
    setProjectColor(preferences.defaultProjectColor);
    setIncludeReadme(false);
    setModal({ kind: "new-project" });
  };
  const toggleFolderCreate = (kind: "file" | "folder") => openNewPath(kind);

  const searchPackages = async () => {
    if (!packageQuery.trim()) return;
    setPackageBusy(true); setPackageProgress("");
    try {
      const response = await fetch(`https://pypi.org/pypi/${encodeURIComponent(packageQuery.trim())}/json`);
      if (response.ok) {
        const data = await response.json();
        setPackageResults([{ name: data.info.name, version: data.info.version, summary: data.info.summary }]);
      } else {
        const responseSearch = await fetch(`https://pypi.org/search/?q=${encodeURIComponent(packageQuery.trim())}`);
        const text = await responseSearch.text();
        const names = [...text.matchAll(/package-snippet__name[^>]*>([^<]+)/g)].slice(0, 5).map(match => match[1].trim());
        setPackageResults(names.map(name => ({ name, version: "Search result", summary: "Open the package on PyPI to inspect compatibility." })));
      }
    } catch { setPackageResults([]); setPackageProgress("PyPI metadata lookup failed. Check your connection or enter an exact package name."); }
    finally { setPackageBusy(false); }
  };
  const installPackage = async (name: string, version?: string) => {
    if (!project || !runtimeRef.current || runtimeStatus !== "ready" || packageBusy) return;
    setPackageBusy(true); setPackageProgress(`Installing ${name}…`);
    addOutput(`pip-compatible install requested: ${name}`, "system");
    try {
      const result = await runtimeRef.current.request({ type: "install", packages: [version && version !== "Search result" ? `${name}==${version}` : name] });
      if (result.type === "result" && result.ok) {
        const normalized = result.packages ?? [];
        const actual = normalized.find(item => item.toLowerCase().startsWith(`${name.toLowerCase()}==`)) ?? name;
        await updateProject({ ...project, installedPackages: [...new Set([...project.installedPackages, actual])], updatedAt: Date.now() });
        setPackageProgress(`${actual} installed and pinned for this project.`); addOutput(`${actual} installed successfully`);
      } else {
        const reason = result.type === "result" ? result.error ?? "Package could not be installed." : "Package could not be installed.";
        setPackageProgress(reason); addOutput(`Install failed: ${reason}`, "stderr");
      }
    } catch (error) { const reason = error instanceof Error ? error.message : String(error); setPackageProgress(reason); addOutput(`Install failed: ${reason}`, "stderr"); }
    finally { setPackageBusy(false); }
  };
  const uninstallPackage = async (entry: string) => {
    if (!project || !runtimeRef.current || runtimeStatus !== "ready" || packageBusy) return;
    const name = entry.split("==")[0];
    if (!window.confirm(`Remove ${entry} from this project's runtime?`)) return;
    setPackageBusy(true);
    try {
      const result = await runtimeRef.current.request({ type: "uninstall", packageName: name });
      if (result.type === "result" && result.ok) {
        await updateProject({ ...project, installedPackages: project.installedPackages.filter(item => item !== entry && item.split("==")[0] !== name) });
        setPackageProgress(`${name} removed.`); addOutput(`${name} removed from project`);
      } else { setPackageProgress(result.type === "result" ? result.error ?? "Uninstall failed." : "Uninstall failed."); }
    } catch (error) { setPackageProgress(error instanceof Error ? error.message : "Uninstall failed."); }
    finally { setPackageBusy(false); }
  };
  const importRequirements = async (file: File) => {
    const text = await file.text(); setReqText(text);
    const packages = text.split(/\r?\n/).map(line => line.trim()).filter(line => line && !line.startsWith("#"));
    if (runtimeStatus === "running" || packageBusy) { setPackageProgress("Finish the current runtime operation before installing requirements."); return; }
    if (!project || !runtimeRef.current || !packages.length) { setPackageProgress("Requirements loaded. Start the isolated browser runtime and click Install requirements."); return; }
    setPackageBusy(true);
    try {
      const result = await runtimeRef.current.request({ type: "install", packages });
      if (result.type === "result" && result.ok) {
        const current = result.packages ?? [];
        await updateProject({ ...project, installedPackages: [...new Set([...project.installedPackages, ...packages.map(item => current.find(pkg => pkg.toLowerCase().startsWith(item.split(/[=<>!~]/)[0].toLowerCase() + "==")) ?? item)])] });
        setPackageProgress("Requirements installed. Unsupported packages are reported by the runtime.");
      } else setPackageProgress(result.type === "result" ? result.error ?? "Requirements install failed." : "Requirements install failed.");
    } catch (error) { setPackageProgress(error instanceof Error ? error.message : "Requirements install failed."); }
    finally { setPackageBusy(false); }
  };
  const downloadRequirements = () => {
    if (!project) return;
    downloadBlob(new Blob([project.installedPackages.join("\n") + (project.installedPackages.length ? "\n" : "")], { type: "text/plain" }), "requirements.txt");
  };
  const saveEnv = async () => {
    if (!project) return;
    try {
      const parsed = envDraft.trim() ? JSON.parse(envDraft) : {};
      if (!parsed || Array.isArray(parsed) || typeof parsed !== "object" || Object.values(parsed).some(value => typeof value !== "string")) throw new Error("Use a JSON object with string values.");
      await updateProject({ ...project, envVars: parsed }); setModal(null); notify("Environment variables saved locally");
    } catch (error) { notify(error instanceof Error ? error.message : "Invalid JSON."); }
  };
  const submitRepl = async () => {
    const code = replText.trim();
    if (!code || !runtimeRef.current || runtimeStatus === "error" || runtimeStatus === "running" || packageBusy || !project) return;
    if (dirty) await persistEditor(false);
    let currentProject = await getProject(project.id) ?? project;
    let runtime = runtimeRef.current;
    const files = currentProject.files.filter(file => file.kind === "file").map(({ path, content }) => ({ path, content }));
    if (!runtime || JSON.stringify(files) !== runtimeFilesSnapshot.current) {
      startRuntime(currentProject);
      runtime = runtimeRef.current;
      if (!runtime) return;
      try { await runtime.ready(); } catch (error) { addOutput(error instanceof Error ? error.message : "Python runtime could not start.", "stderr"); return; }
      currentProject = await getProject(project.id) ?? currentProject;
    }
    setReplText(""); setPanelOpen(true); setPanelTab("repl"); addOutput(`>>> ${code}`, "system");
    setRuntimeStatus("running");
    window.clearTimeout(executionTimeoutRef.current);
    executionTimeoutRef.current = window.setTimeout(() => {
      if (runtimeRef.current !== runtime) return;
      runtime.stop();
      runtimeRef.current = null;
      addOutput(`REPL execution exceeded ${timeoutSeconds} seconds. The sandbox was terminated.`, "stderr");
      setLastResult("error");
      startRuntime(currentProject);
    }, timeoutSeconds * 1000);
    try {
      const result = await runtime.request({ type: "repl", code, envVars: currentProject.envVars });
      window.clearTimeout(executionTimeoutRef.current);
      if (result.type === "result" && result.error === "Execution stopped.") return;
      if (result.type === "result") {
        setRuntimeStatus("ready");
        setRunTime(result.durationMs ?? null);
        setLastResult(result.ok ? "success" : "error");
      }
      if (result.type === "result" && result.value) addOutput(result.value);
    } catch (error) { setRuntimeStatus("error"); addOutput(error instanceof Error ? error.message : "REPL request failed.", "stderr"); }
  };
  const formatCode = async () => {
    if (!runtimeRef.current || runtimeStatus !== "ready" || packageBusy) return;
    try {
      const result = await runtimeRef.current.request({ type: "format", code: editorText });
      if (result.type === "result" && result.ok && result.value !== undefined) { setEditorText(result.value); setDirty(true); }
      else notify(result.type === "result" ? result.error ?? "Formatter unavailable. Install a compatible formatter first." : "Formatter unavailable.");
    } catch (error) { notify(error instanceof Error ? error.message : "Formatter unavailable."); }
  };

  const openFileDialog = (file: ProjectFile) => { setFormValue(file.path); setModal({ kind: "rename-file", file }); };
  const requestDeleteFile = (file: ProjectFile) => {
    if (!preferences.confirmBeforeDelete) void deleteFileItem(file);
    else setModal({ kind: "delete-file", file });
  };
  const activateTab = (id: string) => {
    if (!project) return;
    const file = project.files.find(item => item.id === id);
    if (!file) return;
    const base = dirty && activeFile ? { ...project, files: project.files.map(item => item.id === activeFile.id ? { ...item, content: editorText, updatedAt: Date.now() } : item) } : project;
    if (dirty) { setDirty(false); void saveProject(base); }
    setProject({ ...base, activeFileId: id }); setMobileView("editor");
  };
  const jsonContent = activeFile?.path.endsWith(".json") ? editorText : "";
  const appStyle = {
    "--user-accent": preferences.accentColor,
    "--user-secondary-accent": preferences.secondaryAccentColor,
    "--violet": preferences.theme === "cyberpunk" ? preferences.secondaryAccentColor : preferences.accentColor,
    "--cyan": preferences.theme === "cyberpunk" ? preferences.accentColor : preferences.secondaryAccentColor,
    "--editor-tab-size": `${preferences.tabWidth}ch`,
    "--interface-font-size": `${preferences.interfaceFontSize}px`,
  } as CSSProperties;

  if (booting) return <div className="screen-loader"><LoaderCircle size={15} className="spin" />&nbsp; Opening local workspace…</div>;
  if (!project) return <div className="ide empty-workspace dashboard-shell" style={appStyle} data-theme={preferences.theme} data-density={preferences.density} data-high-contrast={preferences.highContrast}>
    <HomeDashboard
      projects={projects}
      onOpenProject={item => { void switchProject(item); }}
      onCreateProject={createFromProjectButton}
      onImportProject={() => importRef.current?.click()}
      onAboutRuntime={() => setModal({ kind: "runtime-info" })}
    />
    <input ref={importRef} type="file" accept=".zip,application/zip" hidden data-testid="zip-import-input" onChange={event => { const file = event.target.files?.[0]; if (file) startImportZip(file); event.currentTarget.value = ""; }} />
    {toast && <div className="toast" role="status" data-testid="toast-message">{toast}</div>}
    {modal?.kind === "new-project" && <Modal title="Create a project" onClose={() => setModal(null)} footer={<><button className="secondary-btn" onClick={() => setModal(null)}>Cancel</button><button className="primary-btn" onClick={() => void createProject()} data-testid="confirm-create-project"><Plus size={13} /> Create project</button></>}>
      <ProjectCreationForm name={formValue} onNameChange={setFormValue} template={projectTemplate} onTemplateChange={setProjectTemplate} initialFileName={initialFileName} onInitialFileNameChange={setInitialFileName} description={projectDescription} onDescriptionChange={setProjectDescription} color={projectColor} onColorChange={setProjectColor} includeReadme={includeReadme} onIncludeReadmeChange={setIncludeReadme} onEnter={() => void createProject()} />
    </Modal>}
    {modal?.kind === "import-name" && <Modal title="Import project ZIP" onClose={() => { setModal(null); setPendingImport(null); }} footer={<><button className="secondary-btn" onClick={() => { setModal(null); setPendingImport(null); }}>Cancel</button><button className="primary-btn" onClick={() => void finishImportZip()} data-testid="confirm-import-zip"><Upload size={13} /> Import as new project</button></>}>
      <p className="muted-copy">ZIP contents are imported as a separate local project. Nothing else will be overwritten.</p><div className="field"><label>PROJECT NAME</label><input autoFocus value={formValue} onChange={e => setFormValue(e.target.value)} data-testid="import-project-name" /></div>
    </Modal>}
    {modal?.kind === "runtime-info" && <Modal title="A local Python runtime" onClose={() => setModal(null)} footer={<button className="primary-btn" onClick={() => setModal(null)}>Understood</button>}>
      <div className="notice"><Activity size={15} /><span>Python runs in a disposable, sandboxed Pyodide iframe in your browser. It is not a Linux or Bash shell, and code does not run on a server.</span></div>
      <p className="muted-copy">Projects are stored in this browser's IndexedDB. Pyodide is downloaded when a project is opened; package support depends on compatible Python wheels and your network connection.</p>
    </Modal>}
  </div>;
  const isPythonFile = activeFileType?.language === "python";
  const isRunning = isPythonFile && runtimeStatus === "running";
  const openFiles = project.openFileIds.map(id => project.files.find(file => file.id === id)).filter((file): file is ProjectFile => !!file);

  return <main className={`ide ${preferences.compactCodingToolbar ? "compact-toolbar" : ""}`} style={appStyle} data-theme={preferences.theme} data-density={preferences.density} data-high-contrast={preferences.highContrast}>
    <header className="topbar">
      <div className="brand"><div className="brand-mark"><Zap size={15} fill="currentColor" /></div><div className="brand-name">VORTEX <span>CODE IDE</span></div></div>
      <button className="project-select" data-testid="open-project-switcher" onClick={() => { setProjectSearch(""); setModal({ kind: "project-list" }); }}><Folder size={14} color="#168bff" /><strong>{project.name}</strong><ChevronDown size={13} color="#738096" /></button>
      <div className="top-spacer" />
      <div className="top-actions">
        <span className="small-btn hide-mobile" style={{ color: runtimeStatus === "error" && isPythonFile ? "#ff8585" : "#8190a4", cursor: "default" }} data-testid="runtime-version"><span className={`status-dot ${runtimeStatus === "error" && isPythonFile ? "error" : ""}`} style={{ background: runtimeStatus === "error" && isPythonFile ? "#ff7373" : runtimeStatus === "starting" && isPythonFile ? "#d4ad62" : "#45cb9b" }} />{isPythonFile ? runtimeVersion : canPreviewActiveFile ? "Local preview" : activeFileType ? "Syntax only" : "No file"}</span>
        {isPythonFile && <IconButton title="Python package manager" testId="open-packages" onClick={() => { setPackageResults([]); setPackageProgress(""); setModal({ kind: "packages" }); }}><Package size={16} /></IconButton>}
        <IconButton title="Workspace settings and shortcuts" testId="open-settings" onClick={() => setModal({ kind: "settings" })}><Settings2 size={16} /></IconButton>
        <button
          className="primary-btn"
          data-testid={isPythonFile ? "run-python" : canPreviewActiveFile ? "preview-web-file" : "run-unavailable"}
          title={isPythonFile ? "Run Python in the browser sandbox" : canPreviewActiveFile ? "Preview this file in an isolated browser frame" : "This file type has no execution runtime in this workspace"}
          onClick={() => { triggerHaptic(); isRunning ? stopProgram() : void runProgram(); }}
          disabled={isPythonFile ? runtimeStatus === "starting" || packageBusy : !canPreviewActiveFile}
        >
          {isRunning ? <Square size={13} fill="currentColor" /> : canPreviewActiveFile ? <Eye size={14} /> : <Play size={14} fill="currentColor" />}
          {isRunning ? "Stop" : isPythonFile ? "Run" : canPreviewActiveFile ? "Preview" : "Unavailable"}
          <span className="hide-mobile" style={{ opacity: .72 }}>⌘↵</span>
        </button>
      </div>
    </header>
    <div className="workspace">
      <div className={`mobile-overlay ${mobileExplorer ? "open" : ""}`} onClick={() => setMobileExplorer(false)} />
       <Explorer project={project} collapsed={collapsed && !mobileExplorer} activeId={project.activeFileId} showHiddenFiles={preferences.showHiddenFiles} onSelect={selectFile} onToggle={() => { setCollapsed(value => !value); setMobileExplorer(false); }} onCreate={toggleFolderCreate} onRename={openFileDialog} onDelete={requestDeleteFile} onDuplicate={duplicateFile} onImport={() => importRef.current?.click()} onImportFiles={() => sourceRef.current?.click()} onExport={() => setModal({ kind: "project-list" })} />
      <section className={`workbench ${mobileView === "files" ? "desktop-hide" : ""} ${mobileView === "output" || mobileView === "preview" ? "results-view" : ""}`}>
        <div className="editor-toolbar">
          <IconButton title={collapsed ? "Show explorer" : "Hide explorer"} testId="toggle-explorer" className="hide-mobile" onClick={() => setCollapsed(value => !value)}>{collapsed ? <PanelLeftOpen size={15} /> : <PanelLeftClose size={15} />}</IconButton>
          <div className="tabs" role="tablist" aria-label="Open files">{openFiles.map(file => <div className={`tab ${file.id === project.activeFileId ? "active" : ""}`} role="tab" aria-selected={file.id === project.activeFileId} key={file.id} onClick={() => activateTab(file.id)} data-testid={`tab-${file.id}`}><FileTypeIcon path={file.path} size={13} />{safeName(file.path)}{file.id === project.activeFileId && dirty && <Circle size={6} fill="#168bff" stroke="none" />}{openFiles.length > 1 && <button className="tab-close" aria-label={`Close ${safeName(file.path)}`} data-testid={`close-tab-${file.id}`} onClick={event => { event.stopPropagation(); closeTab(file.id); }}><X size={12} /></button>}</div>)}</div>
          {activeFile && <><span className="toolbar-divider" /><IconButton title="Save" testId="save-file" onClick={() => void persistEditor(true)}><Check size={15} /></IconButton><IconButton title="Save as new file" testId="save-as" onClick={saveAs}><Download size={15} /></IconButton><IconButton title="Download source file" testId="download-source" onClick={downloadSource}><ArrowDownToLine size={15} /></IconButton></>}
          <div className="toolbar-spacer" />
          <IconButton title="Search and replace (⌘F)" testId="editor-search" onClick={() => { const view = editorRef.current?.view; if (view) openSearchPanel(view); }}><SearchIcon size={15} /></IconButton>
          <IconButton title="Undo" testId="editor-undo" onClick={() => editorRef.current?.view && undo(editorRef.current.view)}><RefreshCw size={14} /></IconButton>
          {isPythonFile && <IconButton title="Format Python" testId="format-python" onClick={() => void formatCode()} disabled={runtimeStatus !== "ready" || packageBusy}><Braces size={15} /></IconButton>}
          {canPreviewActiveFile && <IconButton title="Open isolated preview" testId="preview-file" onClick={() => { setPanelTab("preview"); setPanelOpen(true); setMobileExplorer(false); setMobileView("preview"); }}><Eye size={15} /></IconButton>}
          {activeFile?.path.endsWith(".json") && <IconButton title="Preview JSON" testId="preview-json" onClick={() => setModal({ kind: "json" })}><Eye size={15} /></IconButton>}
          {isPythonFile && <IconButton title="Run arguments" testId="run-configuration" onClick={() => setModal({ kind: "run-settings" })}><Command size={14} /></IconButton>}
          <IconButton title="Increase editor text size" testId="increase-font" onClick={() => updatePreferences({ editorFontSize: Math.min(preferences.editorFontSize + 1, 24) })}><Plus size={15} /></IconButton>
          <IconButton title="Decrease editor text size" testId="decrease-font" onClick={() => updatePreferences({ editorFontSize: Math.max(preferences.editorFontSize - 1, 10) })}><span style={{ fontSize: 18, lineHeight: 1 }}>−</span></IconButton>
        </div>
        <div className={`editor-area ${preferences.editorTheme === "light" ? "editor-light" : ""} ${preferences.indentationGuides ? "indentation-guides" : ""} ${preferences.minimap ? "with-minimap" : ""}`} data-testid="code-editor">
          {activeFile ? isImagePath(activeFile.path) ? <div className="image-editor-preview" data-testid="image-editor-preview"><img src={activeFile.content} alt={safeName(activeFile.path)} /><span>{safeName(activeFile.path)} · {getFileType(activeFile.path).label}</span></div> : <><CodeMirror key={activeFile.id} ref={editorRef} value={editorText} height="100%" theme={preferences.editorTheme === "light" ? "light" : oneDark} extensions={[getEditorLanguageExtension(activeFile.path), history(), search(), indentUnit.of(preferences.insertSpaces ? " ".repeat(preferences.tabWidth) : "\t"), ...(preferences.wordWrap ? [EditorView.lineWrapping] : []), keymap.of([...defaultKeymap, ...historyKeymap, ...searchKeymap, indentWithTab])]} basicSetup={{ lineNumbers: preferences.lineNumbers, foldGutter: true, highlightActiveLine: preferences.highlightCurrentLine, bracketMatching: preferences.bracketMatching, closeBrackets: preferences.autoCloseBrackets && preferences.autoCloseQuotes, autocompletion: true, indentOnInput: true, highlightSelectionMatches: true }} style={{ height: "100%", fontFamily: "var(--editor-font-family)", fontSize: preferences.editorFontSize, lineHeight: preferences.editorLineHeight }} onChange={value => { setEditorText(value); setDirty(true); }} onCreateEditor={view => {
            if (!preferences.restoreCursorPosition) return;
            try { const position = Number(localStorage.getItem(`vortex-cursor:${project.id}:${activeFile.id}`)); if (Number.isInteger(position) && position >= 0 && position <= view.state.doc.length) view.dispatch({ selection: { anchor: position } }); } catch { /* Cursor restoration is optional when browser storage is unavailable. */ }
          }} onUpdate={update => {
            if (!preferences.restoreCursorPosition || !update.selectionSet) return;
            try { localStorage.setItem(`vortex-cursor:${project.id}:${activeFile.id}`, String(update.state.selection.main.head)); } catch { /* Keep editing if browser storage is unavailable. */ }
           }} data-testid={isPythonFile ? "python-source-editor" : "source-code-editor"} />{preferences.minimap && <pre className="editor-minimap" aria-hidden="true">{editorText.split("\n").slice(0, 100).map(line => line.slice(0, 70) || " ").join("\n")}</pre>}</>
             : <div className="editor-empty"><div style={{ textAlign: "center" }}><FileCode2 size={28} color="#42516a" /><div style={{ marginTop: 10 }}>No file is open</div><button className="secondary-btn" onClick={() => openNewPath("file")} data-testid="empty-new-file"><Plus size={13} /> Create a file</button></div></div>}
          </div>
          <div className="runstrip"><span className="status-dot" style={{ background: lastResult === "error" ? "#ff7373" : runtimeStatus === "starting" ? "#d4ad62" : "#45cb9b" }} /><span>{runtimeStatus === "starting" ? "Starting browser Python…" : isRunning ? "Executing Python…" : runtimeStatus === "error" ? "Python runtime stopped · reload project to restart" : lastResult === "error" ? "Run completed with errors" : lastResult === "success" ? "Run complete" : "Ready to run"}</span>{runTime !== null && preferences.showExecutionTime && <span>· {runTime} ms</span>}<span className="toolbar-spacer" /><button className="small-btn" data-testid="toggle-output" onClick={() => setPanelOpen(value => !value)}>{panelOpen ? "Hide output" : "Show output"} <ChevronDown size={12} /></button></div>
        <section className={`bottom-panel ${panelOpen ? "" : "closed"} ${panelTab === "preview" ? "preview-panel" : ""}`} aria-label={panelTab === "preview" ? "Preview panel" : "Output panel"}>
          <div className="bottom-head">
            <button className={`panel-tab ${panelTab === "output" ? "active" : ""}`} data-testid="output-tab" onClick={() => { setPanelTab("output"); setPanelOpen(true); }}><Terminal size={13} /> OUTPUT</button>
            <button className={`panel-tab ${panelTab === "repl" ? "active" : ""}`} data-testid="repl-tab" onClick={() => { setPanelTab("repl"); setPanelOpen(true); }}><Command size={13} /> PYTHON REPL</button>
            {preferences.preserveRunHistory && <button className={`panel-tab ${panelTab === "history" ? "active" : ""}`} data-testid="run-history-tab" onClick={() => { setPanelTab("history"); setPanelOpen(true); }}><Clock3 size={13} /> HISTORY <span className="history-count">{runHistory.length}</span></button>}
            {canPreviewActiveFile && <button className={`panel-tab ${panelTab === "preview" ? "active" : ""}`} data-testid="web-preview-tab" onClick={() => { setPanelTab("preview"); setPanelOpen(true); setMobileView("preview"); }}><Eye size={13} /> PREVIEW</button>}
            {panelTab !== "preview" ? <div className="output-actions"><span style={{ color: "#606e81", fontSize: 9 }}>{isPythonFile ? runtimeStatus === "ready" ? "BROWSER PYTHON" : runtimeStatus.toUpperCase() : canPreviewActiveFile ? "ISOLATED WEB PREVIEW" : `${activeFileType?.label.toUpperCase() ?? "EDITOR"}`}</span>{panelTab === "repl" && <span className="shell-limitation-chip" title="A Linux or Bash shell is not provisioned">NO SHELL</span>}{panelTab === "history" && runHistory.length > 0 && <IconButton title="Clear saved run history" testId="clear-run-history" onClick={() => void clearSavedHistory()}><Trash2 size={14} /></IconButton>}<IconButton title="Copy output" testId="copy-output" onClick={() => void copyOutput()}><Clipboard size={13} /></IconButton>{panelTab !== "history" && <IconButton title="Clear output" testId="clear-output" onClick={clearOutput}><Trash2 size={14} /></IconButton>}</div> : <span className="preview-security-label">Scripts isolated · network blocked</span>}
          </div>
          {panelTab === "preview" && canPreviewActiveFile ? <div className="web-preview-wrap" data-testid="web-preview-content">
            <iframe title={`${activeFile?.path ?? "File"} preview`} className="web-preview-frame" sandbox="allow-scripts" referrerPolicy="no-referrer" srcDoc={previewDocument?.document ?? ""} data-testid="web-preview-frame" />
            <div className="preview-security-note">Untrusted page scripts run in an isolated frame. Network, storage, and access to this editor are blocked.</div>
          </div> : panelTab === "output" ? <div className="output-body" ref={outputRef} style={{ fontSize: preferences.outputFontSize }} data-testid="output-content">
          {outputs.length ? outputs.map(item => <div className={`output-line ${item.stream === "stderr" ? "stderr" : ""}`} key={item.id}><span className="output-prefix">{item.stream === "stderr" ? "!" : item.stream === "stdout" ? "›" : "·"}</span><span>{item.text}</span></div>)
              : <div className="output-placeholder">Execution output appears here.<br />Python runs in an isolated Pyodide browser runtime — not on a server.</div>}
          </div> : panelTab === "repl" ? <><div className="output-body" data-testid="repl-output">{outputs.filter(item => item.stream !== "system" || item.text.startsWith(">>>")).slice(-35).map(item => <div className={`output-line ${item.stream === "stderr" ? "stderr" : ""}`} key={item.id}><span className="output-prefix">{item.text.startsWith(">>>") ? "" : "›"}</span><span>{item.text}</span></div>)}<div className="output-placeholder">Persistent Python namespace · isolated project runtime · /workspace. This is not a shell.</div></div><div className="terminal-input"><span style={{ color: "#168bff", font: "12px var(--app-font-mono)" }}>&gt;&gt;&gt;</span><input value={replText} onChange={e => setReplText(e.target.value)} onKeyDown={e => { if (e.key === "Enter") void submitRepl(); }} placeholder="Enter a Python expression or statement…" data-testid="repl-input" /><button className="small-btn" onClick={() => void submitRepl()} data-testid="repl-submit" disabled={runtimeStatus !== "ready" || packageBusy}>Run</button></div></>
            : <div className="run-history-list" data-testid="run-history-list">
              {runHistory.length ? runHistory.map(entry => <article className="run-history-entry" key={entry.id}>
                <button type="button" className="run-history-open" onClick={() => void viewHistoryEntry(entry)} data-testid={`view-history-${entry.id}`}>
                  <span className={`history-status ${entry.status}`}>{entry.status}</span>
                  <span className="history-entry-copy"><strong>{entry.projectName} / {entry.filePath}</strong><small>{new Date(entry.createdAt).toLocaleString()}{entry.durationMs !== undefined && preferences.showExecutionTime ? ` · ${entry.durationMs} ms` : ""}</small></span>
                  <ChevronRight size={14} />
                </button>
                <pre>{entry.output.slice(-3).map(item => item.text).join("\n") || "No output captured."}</pre>
              </article>) : <div className="output-placeholder">Completed runs will appear here and stay on this device.</div>}
            </div>}
        </section>
      </section>
    </div>
    <div className="statusbar"><span>{runtimeVersion}</span><span>·</span><span>{activeFile?.path ?? "No file"}</span><div className="right"><span>{dirty ? "Unsaved changes" : "Saved locally"}</span><span>UTF-8</span><span>{activeFileType?.label ?? "Text"}</span></div></div>
    <nav className="mobile-nav" aria-label="Mobile workspace navigation"><button className={mobileView === "files" ? "active" : ""} data-testid="mobile-files" onClick={() => { setMobileExplorer(true); setMobileView("files"); }}><FolderTree size={16} />Files</button><button className={mobileView === "editor" ? "active" : ""} data-testid="mobile-editor" onClick={() => { setMobileExplorer(false); setMobileView("editor"); }}><Code2 size={16} />Editor</button><button className={mobileView === "output" ? "active" : ""} data-testid="mobile-output" onClick={() => { setMobileExplorer(false); setMobileView("output"); setPanelTab("output"); setPanelOpen(true); }}><Terminal size={16} />Output</button>{canPreviewActiveFile && <button className={mobileView === "preview" ? "active" : ""} data-testid="mobile-preview" onClick={() => { setMobileExplorer(false); setMobileView("preview"); setPanelTab("preview"); setPanelOpen(true); }}><Eye size={16} />Preview</button>}</nav>
    <input ref={importRef} type="file" accept=".zip,application/zip" hidden data-testid="zip-import-input" onChange={event => { const file = event.target.files?.[0]; if (file) startImportZip(file); event.currentTarget.value = ""; }} />
    <input ref={sourceRef} type="file" multiple accept=".py,.pyw,.pyi,.html,.htm,.css,.scss,.sass,.less,.js,.mjs,.cjs,.jsx,.ts,.tsx,.c,.h,.cc,.cpp,.cxx,.c+,.hpp,.cs,.java,.go,.rs,.rb,.php,.swift,.kt,.kts,.sh,.bash,.sql,.lua,.pl,.pm,.ps1,.psm1,.r,.scala,.dart,.clj,.cljs,.cljc,.hs,.lhs,.groovy,.gradle,.erl,.hrl,.f,.for,.f90,.f95,.pas,.vb,.json,.jsonc,.md,.markdown,.xml,.yaml,.yml,.toml,.png,.jpg,.jpeg,.gif,.webp,.avif,.bmp,.ico,.svg" hidden data-testid="source-files-import-input" onChange={event => { const files = Array.from(event.currentTarget.files ?? []); event.currentTarget.value = ""; if (files.length) void importSourceFiles(files); }} />
    <input ref={requirementsRef} type="file" accept=".txt,text/plain" hidden data-testid="requirements-import-input" onChange={event => { const file = event.target.files?.[0]; if (file) void importRequirements(file); event.currentTarget.value = ""; }} />
    {toast && <div className="toast" role="status" data-testid="toast-message">{toast}</div>}

    {modal?.kind === "new-project" && <Modal title="Create a project" onClose={() => setModal(null)} footer={<><button className="secondary-btn" onClick={() => setModal(null)}>Cancel</button><button className="primary-btn" onClick={() => void createProject()} data-testid="confirm-create-project"><Plus size={13} /> Create project</button></>}>
      <ProjectCreationForm name={formValue} onNameChange={setFormValue} template={projectTemplate} onTemplateChange={setProjectTemplate} initialFileName={initialFileName} onInitialFileNameChange={setInitialFileName} description={projectDescription} onDescriptionChange={setProjectDescription} color={projectColor} onColorChange={setProjectColor} includeReadme={includeReadme} onIncludeReadmeChange={setIncludeReadme} onEnter={() => void createProject()} />
    </Modal>}
    {modal?.kind === "project-list" && <Modal title="Your projects" onClose={() => setModal(null)}>
      <input className="search-input" placeholder="Search projects…" value={projectSearch} onChange={e => setProjectSearch(e.target.value)} data-testid="search-projects" />
      {visibleProjects.map(item => <div className="project-row" key={item.id} data-testid={`project-row-${item.id}`}><div className="grow" onClick={() => void switchProject(item)} style={{ cursor: "pointer" }}><strong>{item.name}</strong><small>{item.files.filter(file => file.kind === "file").length} files · edited {new Date(item.updatedAt).toLocaleDateString()}</small></div>{item.id === project.id && <span style={{ fontSize: 9, color: "#55adff" }}>OPEN</span>}<IconButton title={`Duplicate ${item.name}`} testId={`duplicate-project-${item.id}`} onClick={() => void duplicateProjectItem(item)}><Copy size={13} /></IconButton><button className="small-btn" onClick={() => void switchProject(item)} data-testid={`switch-project-${item.id}`}>Open</button></div>)}
      <div style={{ display: "flex", gap: 8, marginTop: 3, flexWrap: "wrap" }}><button className="primary-btn" onClick={createFromProjectButton} data-testid="create-project"><Plus size={13} /> New project</button><button className="secondary-btn" onClick={() => importRef.current?.click()} data-testid="import-project"><Upload size={13} /> Import ZIP</button><button className="secondary-btn" onClick={exportZip} data-testid="export-project"><Download size={13} /> Export current</button></div>
      <div style={{ borderTop: "1px solid #202a38", marginTop: 7, paddingTop: 12, display: "flex", gap: 6, flexWrap: "wrap" }}><button className="secondary-btn" onClick={() => { setFormValue(project.name); setModal({ kind: "rename-project" }); }} data-testid="rename-project"><MoreHorizontal size={13} /> Rename</button><button className="secondary-btn danger" onClick={() => preferences.confirmBeforeDelete ? setModal({ kind: "delete-project" }) : void removeProject()} data-testid="delete-project"><Trash2 size={13} /> Delete current</button></div>
    </Modal>}
    {modal?.kind === "rename-project" && <Modal title="Rename project" onClose={() => setModal(null)} footer={<><button className="secondary-btn" onClick={() => setModal({ kind: "project-list" })}>Cancel</button><button className="primary-btn" onClick={() => void renameProject()} data-testid="confirm-rename-project">Save name</button></>}>
      <div className="field"><label>PROJECT NAME</label><input autoFocus value={formValue} onChange={e => setFormValue(e.target.value)} data-testid="rename-project-input" /></div></Modal>}
    {modal?.kind === "delete-project" && <Modal title="Delete project?" onClose={() => setModal({ kind: "project-list" })} footer={<><button className="secondary-btn" onClick={() => setModal({ kind: "project-list" })}>Keep project</button><button className="primary-btn" style={{ background: "#b84752", borderColor: "#b84752" }} onClick={() => void removeProject()} data-testid="confirm-delete-project">Delete permanently</button></>}>
      <div className="notice"><AlertCircle size={16} className="danger" /><span>This removes <strong>{project.name}</strong> and all its local files from this browser. This cannot be undone. Export a ZIP first if you need a backup.</span></div></Modal>}
    {modal?.kind === "new-file" && <Modal title={formValue === "" ? "Create file" : "New file or folder"} onClose={() => setModal(null)} footer={<><button className="secondary-btn" onClick={() => setModal(null)}>Cancel</button><button className="primary-btn" onClick={() => void makeSaveAs()} data-testid="confirm-save-as"><Download size={13} /> Save as new file</button><button className="primary-btn" onClick={() => void createFile("file")} data-testid="confirm-create-file"><FilePlus2 size={13} /> Create file</button></>}>
      <div className="field"><label>PROJECT-RELATIVE PATH</label><input autoFocus value={formValue} onChange={e => setFormValue(e.target.value)} placeholder="src/analysis.py" data-testid="file-path-input" /><small className="muted-copy">Existing paths are never overwritten. Create parent folders before nested files.</small></div>
      <div style={{ display: "flex", gap: 8 }}><button className="secondary-btn" onClick={() => void createFile("folder")} data-testid="confirm-create-folder"><FolderPlus size={13} /> Create folder at this path</button>{activeFile && <span className="muted-copy" style={{ alignSelf: "center" }}>“Save as” copies current editor text.</span>}</div>
    </Modal>}
    {modal?.kind === "rename-file" && <Modal title="Rename file or folder" onClose={() => setModal(null)} footer={<><button className="secondary-btn" onClick={() => setModal(null)}>Cancel</button><button className="primary-btn" onClick={() => void renameFile()} data-testid="confirm-rename-file">Rename</button></>}>
      <p className="muted-copy">Renaming a folder also updates every child path. Existing paths are protected from overwrite.</p><div className="field"><label>NEW PROJECT-RELATIVE PATH</label><input autoFocus value={formValue} onChange={e => setFormValue(e.target.value)} data-testid="rename-file-input" /></div></Modal>}
    {modal?.kind === "delete-file" && <Modal title="Delete this path?" onClose={() => setModal(null)} footer={<><button className="secondary-btn" onClick={() => setModal(null)}>Cancel</button><button className="primary-btn" style={{ background: "#b84752", borderColor: "#b84752" }} onClick={() => void removeFile()} data-testid="confirm-delete-file"><Trash2 size={13} /> Delete</button></>}>
      <div className="notice"><AlertCircle size={16} className="danger" /><span>Delete <strong>{modal.file?.path}</strong>?{modal.file?.kind === "folder" ? " All files inside this folder will also be removed." : ""} This cannot be undone.</span></div></Modal>}
    {modal?.kind === "run-settings" && <Modal title="Run configuration" onClose={() => setModal(null)} footer={<button className="primary-btn" onClick={() => setModal(null)}>Done</button>}><div className="field"><label>SPACE-SEPARATED SCRIPT ARGUMENTS</label><input value={argsText} onChange={e => setArgsText(e.target.value)} placeholder={'--limit 24 "sample file.csv"'} data-testid="script-arguments" /></div><div className="field"><label>EXECUTION TIMEOUT · {preferences.timeoutSeconds}s</label><input type="range" min="1" max="120" value={preferences.timeoutSeconds} onChange={e => updatePreferences({ timeoutSeconds: Number(e.target.value) })} data-testid="execution-timeout" /></div><p className="muted-copy">Arguments populate sys.argv; quoted values can contain spaces. Execution is terminated if it exceeds this limit. Environment variables are applied to os.environ in the isolated browser runtime.</p></Modal>}
    {modal?.kind === "packages" && <Modal title="Python packages" onClose={() => setModal(null)}>
      <div className="notice"><Info size={15} /><span>Installs use <strong>micropip inside Pyodide</strong>. Only compatible pure-Python or Pyodide-supported wheels work; native system extensions and general pip access are unavailable. Dependencies are restored per project.</span></div>
      <div style={{ display: "flex", gap: 7 }}><input className="search-input" value={packageQuery} onChange={e => setPackageQuery(e.target.value)} onKeyDown={e => { if (e.key === "Enter") void searchPackages(); }} placeholder="Search PyPI package (e.g. requests)" data-testid="package-search-input" /><button className="primary-btn" onClick={() => void searchPackages()} disabled={packageBusy} data-testid="search-package">{packageBusy ? <LoaderCircle size={13} /> : <SearchIcon size={13} />} Search</button></div>
      {packageProgress && <div className="muted-copy" data-testid="package-status">{packageProgress}</div>}
      {packageResults.map(item => <div className="package-row" key={item.name}><div className="grow"><strong>{item.name} <span style={{ color: "#6e7e94" }}>v{item.version}</span></strong><small>{item.summary}</small></div><button className="secondary-btn" disabled={packageBusy || runtimeStatus !== "ready"} onClick={() => void installPackage(item.name, item.version)} data-testid={`install-${item.name}`}>Install</button><a href={`https://pypi.org/project/${encodeURIComponent(item.name)}/`} target="_blank" rel="noreferrer" className="icon-btn" aria-label={`Open ${item.name} on PyPI`}><ExternalLink size={14} /></a></div>)}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: 4 }}><strong style={{ fontSize: 11, color: "#c7d3e3" }}>Project dependencies</strong><div style={{ display: "flex", gap: 5 }}><button className="secondary-btn" onClick={() => requirementsRef.current?.click()} data-testid="import-requirements">Import requirements</button><button className="secondary-btn" onClick={downloadRequirements} data-testid="export-requirements"><Download size={12} /> requirements.txt</button></div></div>
      {project.installedPackages.length ? project.installedPackages.map(entry => <div className="package-row" key={entry}><Package size={14} color="#62b5ff" /><div className="grow"><strong>{entry}</strong><small>Pinned in this project · restored when runtime starts</small></div><button className="icon-btn" title={`Uninstall ${entry}`} data-testid={`uninstall-${entry}`} disabled={packageBusy || runtimeStatus !== "ready"} onClick={() => void uninstallPackage(entry)}><Trash2 size={14} /></button></div>) : <div className="muted-copy" style={{ padding: "5px 0" }}>No project dependencies yet.</div>}
      {reqText && <div className="field"><label>REQUIREMENTS CONTENT</label><textarea value={reqText} onChange={e => setReqText(e.target.value)} data-testid="requirements-content" /><button className="secondary-btn" disabled={packageBusy} onClick={() => void (async () => { const file = new File([reqText], "requirements.txt"); await importRequirements(file); })()} data-testid="install-requirements">Install requirements</button></div>}
    </Modal>}
    {modal?.kind === "requirements" && <Modal title="Import requirements" onClose={() => setModal(null)}><div className="field"><label>PACKAGE NAMES / PINS</label><textarea value={reqText} onChange={e => setReqText(e.target.value)} placeholder="requests==2.32.3" /></div></Modal>}
    {modal?.kind === "env" && <Modal title="Environment variables" onClose={() => setModal(null)} footer={<><button className="secondary-btn" onClick={() => setModal(null)}>Cancel</button><button className="primary-btn" onClick={() => void saveEnv()} data-testid="save-env-vars">Save variables</button></>}>
      <div className="notice"><Info size={15} /><span>Values are stored in this browser's IndexedDB and passed to Python. Do not store passwords, tokens, or other secrets here.</span></div><div className="field"><label>JSON OBJECT OF STRING VALUES</label><textarea value={envDraft} onChange={e => setEnvDraft(e.target.value)} data-testid="env-vars-editor" /></div></Modal>}
    {modal?.kind === "settings" && <Modal title="Workspace settings" onClose={() => setModal(null)}>
      <div className="notice"><Activity size={15} /><span><strong>Browser-only execution.</strong> Python runs in an isolated, disposable Pyodide iframe in this browser. Package support depends on compatible wheels. Projects, preferences and run history remain local unless you export them.</span></div>
      <SettingsPanel
        preferences={preferences}
        onUpdate={updatePreferences}
        projectCount={projects.length}
        storageUsage={storageEstimate ? formatBytes(storageEstimate.usage) : "Unavailable"}
        storageQuota={storageEstimate?.quota ? formatBytes(storageEstimate.quota) : "Unavailable"}
        onExportProject={() => void exportZip()}
        onExportBackup={() => void exportAllProjects()}
        onImportBackup={beginBackupImport}
        onExportPreferences={exportSettings}
        onImportPreferences={importSettings}
        onResetPreferences={() => void resetPreferences()}
        onClearProjects={() => setModal({ kind: "clear-storage" })}
        onOpenRunSettings={() => setModal({ kind: "run-settings" })}
        onOpenEnvironment={() => { setEnvDraft(JSON.stringify(project.envVars, null, 2)); setModal({ kind: "env" }); }}
        onRenameProject={() => { setFormValue(project.name); setModal({ kind: "rename-project" }); }}
        onImportPython={() => sourceRef.current?.click()}
      />
    </Modal>}
    {modal?.kind === "json" && <Modal title="JSON preview" onClose={() => setModal(null)}><pre className="json-view">{(() => { try { return JSON.stringify(JSON.parse(jsonContent), null, 2); } catch (error) { return error instanceof Error ? `Invalid JSON: ${error.message}\n\n${jsonContent}` : jsonContent; } })()}</pre><button className="secondary-btn" onClick={() => { void navigator.clipboard?.writeText(jsonContent); notify("JSON copied"); }} data-testid="copy-json"><Clipboard size={13} /> Copy JSON</button></Modal>}
    {modal?.kind === "import-name" && <Modal title="Import project ZIP" onClose={() => { setModal(null); setPendingImport(null); }} footer={<><button className="secondary-btn" onClick={() => { setModal(null); setPendingImport(null); }}>Cancel</button><button className="primary-btn" onClick={() => void finishImportZip()} data-testid="confirm-import-zip"><Upload size={13} /> Import as new project</button></>}>
      <p className="muted-copy">ZIP contents are imported into a separate new project; nothing in your existing workspace will be overwritten.</p><div className="field"><label>PROJECT NAME</label><input value={formValue} onChange={e => setFormValue(e.target.value)} data-testid="import-project-name" /></div></Modal>}
    {modal?.kind === "restore-backup" && <Modal title="Restore project backup?" onClose={() => { setModal(null); setPendingBackupImport(null); }} footer={<><button className="secondary-btn" onClick={() => { setModal(null); setPendingBackupImport(null); }}>Cancel</button><button className="primary-btn" onClick={() => void finishBackupImport()} data-testid="confirm-restore-backup"><Upload size={13} /> Restore as new projects</button></>}>
      <div className="notice"><Info size={15} /><span>Backup projects are added as new local copies. Existing projects are not intentionally replaced. Check the backup file before restoring.</span></div>
      <p className="muted-copy">Selected file: <strong>{pendingBackupImport?.name ?? "none"}</strong></p>
    </Modal>}
    {modal?.kind === "clear-storage" && <Modal title="Delete every local project?" onClose={() => setModal(null)} footer={<><button className="secondary-btn" onClick={() => setModal(null)}>Keep projects</button><button className="primary-btn danger-fill" onClick={() => void removeAllProjects()} data-testid="confirm-clear-projects">Delete all projects</button></>}>
      <div className="notice"><AlertCircle size={16} className="danger" /><span>This permanently deletes all {projects.length} projects and their files from this browser. Export a backup first if you may need them later. This does not delete the separately saved editor preferences.</span></div>
    </Modal>}
  </main>;
}

export default App;
